/**
 * Multi-Tenant Enterprise IMS — Database Driver
 *
 * HIERARCHY ENFORCEMENT:
 *   Super Admin      → sees everything, manages all enterprises
 *   Enterprise Admin  → scoped to their enterpriseId, manages branches/users/products/orders within it
 *   Branch Admin      → scoped to their branchId, manages warehouses/users/orders within it
 *   Warehouse Admin   → scoped to their warehouseId, manages stock/orders within it
 *
 * All findMany/findById/create/update/remove operations accept an AuthContext
 * that enforces tenant boundaries. A warehouse_admin can NEVER see data from
 * another warehouse, even if they guess the ID.
 */

import mysql from 'mysql2/promise'

// ─── Core Types ─────────────────────────────────────────────

export type Role = 'super_admin' | 'enterprise_admin' | 'branch_admin' | 'warehouse_admin'

export interface AuthContext {
  userId: number
  role: Role
  enterpriseId: number | null
  branchId: number | null
  warehouseId: number | null
}

export interface Enterprise {
  id: number; name: string; code: string
  contactEmail: string; contactPhone: string; address: string
  isActive: boolean; maxBranches: number; maxWarehouses: number; maxUsers: number
  createdAt: string; updatedAt: string
}

export interface EnterpriseFeature {
  id: number; enterpriseId: number; feature: string; enabled: boolean
}

export interface Branch {
  id: number; enterpriseId: number; name: string; code: string
  location: string; managerName: string; managerEmail: string; isActive: boolean
  createdAt: string; updatedAt: string
}

export interface Warehouse {
  id: number; enterpriseId: number; branchId: number; name: string; code: string
  location: string; capacity: number; managerName: string; isActive: boolean
  createdAt: string; updatedAt: string
}

export interface User {
  id: number; enterpriseId: number | null; branchId: number | null; warehouseId: number | null
  username: string; email: string; fullName: string; role: Role
  isActive: boolean; passwordHash: string
  createdAt: string; updatedAt: string
}

export interface Category {
  id: number; enterpriseId: number; name: string; description: string
  createdAt: string; updatedAt: string
}

export interface Supplier {
  id: number; enterpriseId: number; name: string; contactPerson: string; email: string
  phone: string; address: string
  createdAt: string; updatedAt: string
}

export interface Product {
  id: number; enterpriseId: number; name: string; sku: string; description: string
  categoryId: number | null; price: number; cost: number; unit: string
  reorderLevel: number; isActive: boolean
  createdAt: string; updatedAt: string
}

export interface Stock {
  id: number; productId: number; warehouseId: number; quantity: number
  createdAt: string; updatedAt: string
}

export interface Order {
  id: number; enterpriseId: number; type: 'purchase' | 'sales'
  supplierId: number | null; warehouseId: number | null
  status: 'pending' | 'approved' | 'shipped' | 'received' | 'cancelled'
  totalAmount: number; notes: string; createdBy: number | null
  createdAt: string; updatedAt: string
}

export interface OrderItem {
  id: number; orderId: number; productId: number; warehouseId: number
  quantity: number; unitPrice: number
  createdAt: string; updatedAt: string
}

export interface AuditLog {
  id: number; userId: number | null; enterpriseId: number | null
  action: string; entity: string; entityId: number | null
  details: string; createdAt: string
}

// ─── Inventory Batches ─────────────────────────────────────

export interface BatchEntry {
  id: number; batchId: number; productId: number; warehouseId: number
  quantity: number; unit: string; costPerUnit: number
  notes: string; createdAt: string; updatedAt: string
}

export interface Batch {
  id: number; enterpriseId: number; warehouseId: number
  batchCode: string; supplierId: number | null; personName: string
  personPhone: string; personEmail: string; notes: string
  status: 'open' | 'closed' | 'cancelled'
  entries: BatchEntry[]
  createdAt: string; updatedAt: string
}

// ─── Stock Out Recorder ────────────────────────────────────

export interface StockOutItem {
  id: number; recorderId: number; productId: number; warehouseId: number
  quantity: number; unit: string
  isReturnable: boolean; returnDeadline: string | null
  notes: string; createdAt: string
}

export interface StockOutRecorder {
  id: number; enterpriseId: number; warehouseId: number
  recorderCode: string; personName: string; personPhone: string
  personEmail: string; personAddress: string; notes: string
  status: 'draft' | 'confirmed' | 'partial_return' | 'returned' | 'cancelled'
  items: StockOutItem[]
  createdBy: number | null; createdAt: string; updatedAt: string
}

// ─── Measurements ──────────────────────────────────────────

export const MEASUREMENTS = [
  "Acre","Ampere","Ampule","Bag","Baker's Dozen","Bale","Bar","Barrel",
  "Basket","Batch","Bin","Block","Bolt","Bottle","Bouquet","Bowl",
  "Box","BTU","Bucket","Bulb","Bunch","Bundle","Bushel","Can",
  "Capsule","Carat","Cart","Carton","Case","cc","Centimeter","Clove",
  "cm","Coil","Cone","Cord","Crate","cu.m","Cubic Centimeter","Cubic Foot",
  "Cubic Inch","Cup","Day","Dozen","Drawer","Drop","Drum","Ear",
  "Feet","Flask","Fluid Ounce","Foot","g","Gallon","Gallons","Gram",
  "Gross","Half Dozen","Hand","Hank","Head","Hectare","Hogshead","Hour",
  "in","Inch","Jar","Jug","Keg","kg","Kilogram","Kilometer",
  "Kilowatt","km","Kuntal","kWh","l","Link","Liter","Litre",
  "Load","Loaf","Long Ton","m","Meter","Metric Ton","mg","mi",
  "Microgram","Mile","Milligram","Milliliter","Millimeter","Minute","ml","mm",
  "Month","Mug","Nautical Mile","nmi","Ounce","Ounces","pac","Pack",
  "Package","Packet","Pair","Pallet","pcs","Peck","Piece","Pieces",
  "Pile","Pint","Pod","Pouch","Pound","Pounds","Quart","Quintal",
  "Ream","Roll","Sachet","Sack","Score","Second","Set","Sheet",
  "Short Ton","Skid","Slab","Spool","sqcm","sqft","sqin","sqkm",
  "sqm","sqmm","Square Centimeter","Square Foot","Square Inch","Square Kilometer","Square Millimeter","Square Yard",
  "sqyd","Stack","Stalk","Stem","Stick","Stone","Strip","Tablespoon",
  "Tablet","Teaspoon","Tin","Tola","Ton","Tonne","Tray","Tub",
  "Tube","Unit","Vial","Volt","Watt","Week","Yard","yd",
  "Year"
] as const

export type Measurement = typeof MEASUREMENTS[number]

// ─── Tenant Scoping Helpers ─────────────────────────────────

function scopeEnterpriseId(ctx: AuthContext): number | null {
  if (ctx.role === 'super_admin') return null // sees all
  return ctx.enterpriseId
}

function scopeBranchId(ctx: AuthContext): number | null {
  if (ctx.role === 'super_admin' || ctx.role === 'enterprise_admin') return null
  return ctx.branchId
}

function scopeWarehouseId(ctx: AuthContext): number | null {
  if (ctx.role === 'warehouse_admin') return ctx.warehouseId
  return null
}

/** Check if a user context can access a specific enterprise */
function canAccessEnterprise(ctx: AuthContext, eid: number): boolean {
  if (ctx.role === 'super_admin') return true
  return ctx.enterpriseId === eid
}

/** Check if a user context can access a specific branch */
function canAccessBranch(ctx: AuthContext, eid: number, bid: number): boolean {
  if (!canAccessEnterprise(ctx, eid)) return false
  if (ctx.role === 'super_admin' || ctx.role === 'enterprise_admin') return true
  return ctx.branchId === bid
}

/** Check if a user context can access a specific warehouse */
function canAccessWarehouse(ctx: AuthContext, eid: number, bid: number, wid: number): boolean {
  if (!canAccessBranch(ctx, eid, bid)) return false
  if (ctx.role === 'warehouse_admin') return ctx.warehouseId === wid
  return true
}

/** Check if actor can manage a target user based on hierarchy */
function canManageUser(ctx: AuthContext, target: User): boolean {
  if (ctx.role === 'super_admin') return true
  if (ctx.role === 'enterprise_admin') {
    // Can only manage users in same enterprise, and only lower roles
    if (target.enterpriseId !== ctx.enterpriseId) return false
    const roleOrder: Record<Role, number> = { super_admin: 0, enterprise_admin: 1, branch_admin: 2, warehouse_admin: 3 }
    return roleOrder[ctx.role] < roleOrder[target.role]
  }
  if (ctx.role === 'branch_admin') {
    // Can only manage users in same branch, only warehouse_admins
    if (target.branchId !== ctx.branchId) return false
    return target.role === 'warehouse_admin'
  }
  return false // warehouse_admin cannot manage any users
}

// ─── Persistence ─────────────────────────────────────────

const isServer = typeof window === 'undefined'
let DATA_FILE = ''

function persist() {
  if (!isServer) return // Only persist on server side
  try {
    const fs = require('fs')
    const path = require('path')
    if (!DATA_FILE) DATA_FILE = path.join(process.cwd(), 'db', 'ims-data.json')
    const data = {
      nextId,
      enterprises, features, branches, warehouses, users,
      categories, suppliers, products, stock, orders, orderItems,
      auditLogs, batches, stockOutRecorders,
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8')
  } catch (e) { console.error('Persist error:', e) }
}

function loadPersisted() {
  if (!isServer) return false // Only load on server side
  try {
    const fs = require('fs')
    const path = require('path')
    DATA_FILE = path.join(process.cwd(), 'db', 'ims-data.json')
    if (!fs.existsSync(DATA_FILE)) return false
    const raw = fs.readFileSync(DATA_FILE, 'utf-8')
    if (!raw || raw.trim().length < 10) return false
    const data = JSON.parse(raw)
    if (!data.enterprises || !Array.isArray(data.enterprises)) return false
    nextId = data.nextId || 200
    // Restore all arrays (splice + push to keep same references)
    const restore = <T>(arr: T[], src: T[]) => { arr.splice(0, arr.length, ...src) }
    restore(enterprises, data.enterprises)
    restore(features, data.features || [])
    restore(branches, data.branches || [])
    restore(warehouses, data.warehouses || [])
    restore(users, data.users || [])
    restore(categories, data.categories || [])
    restore(suppliers, data.suppliers || [])
    restore(products, data.products || [])
    restore(stock, data.stock || [])
    restore(orders, data.orders || [])
    restore(orderItems, data.orderItems || [])
    restore(auditLogs, data.auditLogs || [])
    restore(batches, data.batches || [])
    restore(stockOutRecorders, data.stockOutRecorders || [])
    console.log(`[DB] Loaded persisted data: ${enterprises.length} enterprises, ${products.length} products, ${stock.length} stock levels`)
    return true
  } catch (e) { console.error('Load persisted error:', e); return false }
}

// ─── In-Memory Data Store ───────────────────────────────────

const now = () => new Date().toISOString()
let nextId = 200

const enterprises: Enterprise[] = [
  { id: 1, name: 'Acme Corporation', code: 'ACME', contactEmail: 'admin@acme.com', contactPhone: '+1-555-0100', address: '100 Business Ave, New York, NY', isActive: true, maxBranches: 10, maxWarehouses: 20, maxUsers: 50, createdAt: now(), updatedAt: now() },
  { id: 2, name: 'TechStart Inc', code: 'TECH', contactEmail: 'admin@techstart.com', contactPhone: '+1-555-0200', address: '200 Tech Blvd, San Francisco, CA', isActive: true, maxBranches: 5, maxWarehouses: 10, maxUsers: 25, createdAt: now(), updatedAt: now() },
  { id: 3, name: 'GlobalTrade Ltd', code: 'GTRADE', contactEmail: 'admin@globaltrade.com', contactPhone: '+1-555-0300', address: '300 Trade St, London, UK', isActive: true, maxBranches: 8, maxWarehouses: 15, maxUsers: 40, createdAt: now(), updatedAt: now() },
]

const features: EnterpriseFeature[] = [
  { id: 1, enterpriseId: 1, feature: 'inventory', enabled: true },
  { id: 2, enterpriseId: 1, feature: 'orders', enabled: true },
  { id: 3, enterpriseId: 1, feature: 'suppliers', enabled: true },
  { id: 4, enterpriseId: 1, feature: 'audit_log', enabled: true },
  { id: 5, enterpriseId: 1, feature: 'multi_warehouse', enabled: true },
  { id: 6, enterpriseId: 1, feature: 'api_access', enabled: false },
  { id: 7, enterpriseId: 2, feature: 'inventory', enabled: true },
  { id: 8, enterpriseId: 2, feature: 'orders', enabled: true },
  { id: 9, enterpriseId: 2, feature: 'suppliers', enabled: false },
  { id: 10, enterpriseId: 2, feature: 'audit_log', enabled: false },
  { id: 11, enterpriseId: 2, feature: 'multi_warehouse', enabled: true },
  { id: 12, enterpriseId: 2, feature: 'api_access', enabled: false },
  { id: 13, enterpriseId: 3, feature: 'inventory', enabled: true },
  { id: 14, enterpriseId: 3, feature: 'orders', enabled: true },
  { id: 15, enterpriseId: 3, feature: 'suppliers', enabled: true },
  { id: 16, enterpriseId: 3, feature: 'audit_log', enabled: true },
  { id: 17, enterpriseId: 3, feature: 'multi_warehouse', enabled: true },
  { id: 18, enterpriseId: 3, feature: 'api_access', enabled: true },
]

const branches: Branch[] = [
  { id: 1, enterpriseId: 1, name: 'North Division', code: 'ACME-N', location: 'Boston, MA', managerName: 'Alice Johnson', managerEmail: 'alice@acme.com', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, name: 'South Division', code: 'ACME-S', location: 'Atlanta, GA', managerName: 'Bob Smith', managerEmail: 'bob@acme.com', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 1, name: 'West Division', code: 'ACME-W', location: 'Seattle, WA', managerName: 'Carol West', managerEmail: 'carol@acme.com', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 4, enterpriseId: 2, name: 'Headquarters', code: 'TECH-HQ', location: 'San Francisco, CA', managerName: 'David Chen', managerEmail: 'david@techstart.com', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 5, enterpriseId: 3, name: 'London Office', code: 'GTRADE-LON', location: 'London, UK', managerName: 'Emma Wright', managerEmail: 'emma@globaltrade.com', isActive: true, createdAt: now(), updatedAt: now() },
]

const warehouses: Warehouse[] = [
  { id: 1, enterpriseId: 1, branchId: 1, name: 'Boston Main WH', code: 'ACME-N-W1', location: 'Industrial Park, Boston', capacity: 10000, managerName: 'Dave Wilson', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, branchId: 1, name: 'Boston Overflow', code: 'ACME-N-W2', location: 'Secondary Lot, Boston', capacity: 5000, managerName: 'Dave Wilson', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 1, branchId: 2, name: 'Atlanta WH', code: 'ACME-S-W1', location: 'South Industrial, Atlanta', capacity: 8000, managerName: 'Eva Brown', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 4, enterpriseId: 1, branchId: 3, name: 'Seattle WH', code: 'ACME-W-W1', location: 'Port District, Seattle', capacity: 12000, managerName: 'Frank Green', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 5, enterpriseId: 2, branchId: 4, name: 'SF Main Warehouse', code: 'TECH-HQ-W1', location: 'Downtown SF', capacity: 6000, managerName: 'Grace Lee', isActive: true, createdAt: now(), updatedAt: now() },
  { id: 6, enterpriseId: 3, branchId: 5, name: 'London Warehouse', code: 'GTRADE-LON-W1', location: 'Heathrow Area, London', capacity: 15000, managerName: 'Henry Clark', isActive: true, createdAt: now(), updatedAt: now() },
]

const users: User[] = [
  // Super Admin — no enterprise/branch/warehouse binding
  { id: 1, enterpriseId: null, branchId: null, warehouseId: null, username: 'superadmin', email: 'super@ims.com', fullName: 'Super Administrator', role: 'super_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },

  // Enterprise Admins — bound to enterprise only
  { id: 2, enterpriseId: 1, branchId: null, warehouseId: null, username: 'acmeadmin', email: 'admin@acme.com', fullName: 'Acme Enterprise Admin', role: 'enterprise_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 5, enterpriseId: 2, branchId: null, warehouseId: null, username: 'techadmin', email: 'admin@techstart.com', fullName: 'TechStart Enterprise Admin', role: 'enterprise_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 10, enterpriseId: 3, branchId: null, warehouseId: null, username: 'globaladmin', email: 'admin@globaltrade.com', fullName: 'GlobalTrade Enterprise Admin', role: 'enterprise_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },

  // Branch Admins — bound to enterprise + branch
  { id: 3, enterpriseId: 1, branchId: 1, warehouseId: null, username: 'northadmin', email: 'alice@acme.com', fullName: 'Alice Johnson (North)', role: 'branch_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 6, enterpriseId: 1, branchId: 2, warehouseId: null, username: 'southadmin', email: 'bob@acme.com', fullName: 'Bob Smith (South)', role: 'branch_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 11, enterpriseId: 2, branchId: 4, warehouseId: null, username: 'hqadmin', email: 'david@techstart.com', fullName: 'David Chen (HQ)', role: 'branch_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },

  // Warehouse Admins — bound to enterprise + branch + warehouse
  { id: 4, enterpriseId: 1, branchId: 1, warehouseId: 1, username: 'bostonwh', email: 'dave@acme.com', fullName: 'Dave Wilson (Boston WH)', role: 'warehouse_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 7, enterpriseId: 1, branchId: 1, warehouseId: 2, username: 'bostonwh2', email: 'dave2@acme.com', fullName: 'Dave Wilson (Boston Overflow)', role: 'warehouse_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 8, enterpriseId: 1, branchId: 2, warehouseId: 3, username: 'atlantawh', email: 'eva@acme.com', fullName: 'Eva Brown (Atlanta WH)', role: 'warehouse_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
  { id: 9, enterpriseId: 2, branchId: 4, warehouseId: 5, username: 'sfwh', email: 'grace@techstart.com', fullName: 'Grace Lee (SF WH)', role: 'warehouse_admin', isActive: true, passwordHash: 'admin123', createdAt: now(), updatedAt: now() },
]

const categories: Category[] = [
  { id: 1, enterpriseId: 1, name: 'Electronics', description: 'Electronic devices and components', createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, name: 'Furniture', description: 'Office and warehouse furniture', createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 1, name: 'Raw Materials', description: 'Raw materials for manufacturing', createdAt: now(), updatedAt: now() },
  { id: 4, enterpriseId: 2, name: 'Software', description: 'Software licenses and SaaS', createdAt: now(), updatedAt: now() },
  { id: 5, enterpriseId: 2, name: 'Hardware', description: 'Computer hardware', createdAt: now(), updatedAt: now() },
  { id: 6, enterpriseId: 3, name: 'Imported Goods', description: 'Imported trade goods', createdAt: now(), updatedAt: now() },
]

const suppliers: Supplier[] = [
  { id: 1, enterpriseId: 1, name: 'TechCorp Supplies', contactPerson: 'John Smith', email: 'john@techcorp.com', phone: '+1-555-0101', address: '123 Tech Blvd', createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, name: 'Global Materials', contactPerson: 'Sarah Chen', email: 'sarah@globalmat.com', phone: '+1-555-0202', address: '456 Commerce St', createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 3, name: 'UK Imports Ltd', contactPerson: 'James Brown', email: 'james@ukimports.com', phone: '+44-20-1234', address: '10 Import Lane, London', createdAt: now(), updatedAt: now() },
]

const products: Product[] = [
  { id: 1, enterpriseId: 1, name: 'Laptop Pro 15"', sku: 'ACME-ELEC-001', description: 'High-end business laptop', categoryId: 1, price: 1299.99, cost: 850, unit: 'pcs', reorderLevel: 10, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, name: 'Wireless Keyboard', sku: 'ACME-ELEC-002', description: 'Bluetooth ergonomic keyboard', categoryId: 1, price: 79.99, cost: 25, unit: 'pcs', reorderLevel: 50, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 1, name: 'Office Desk', sku: 'ACME-FURN-001', description: 'Adjustable standing desk', categoryId: 2, price: 449.99, cost: 200, unit: 'pcs', reorderLevel: 8, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 4, enterpriseId: 1, name: 'Network Switch 24-port', sku: 'ACME-ELEC-003', description: 'Enterprise network switch', categoryId: 1, price: 299.99, cost: 140, unit: 'pcs', reorderLevel: 3, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 5, enterpriseId: 1, name: 'Steel Shelving Unit', sku: 'ACME-FURN-002', description: 'Heavy-duty warehouse shelving', categoryId: 2, price: 189.99, cost: 80, unit: 'pcs', reorderLevel: 5, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 6, enterpriseId: 2, name: 'Cloud License Pro', sku: 'TECH-SW-001', description: 'Annual cloud software license', categoryId: 4, price: 599.99, cost: 200, unit: 'license', reorderLevel: 0, isActive: true, createdAt: now(), updatedAt: now() },
  { id: 7, enterpriseId: 3, name: 'Circuit Board A', sku: 'GTRADE-IMP-001', description: 'Imported circuit boards', categoryId: 6, price: 45.50, cost: 18, unit: 'pcs', reorderLevel: 100, isActive: true, createdAt: now(), updatedAt: now() },
]

const stock: Stock[] = [
  { id: 1, productId: 1, warehouseId: 1, quantity: 25, createdAt: now(), updatedAt: now() },
  { id: 2, productId: 2, warehouseId: 1, quantity: 150, createdAt: now(), updatedAt: now() },
  { id: 3, productId: 3, warehouseId: 1, quantity: 5, createdAt: now(), updatedAt: now() },
  { id: 4, productId: 4, warehouseId: 1, quantity: 2, createdAt: now(), updatedAt: now() },
  { id: 5, productId: 1, warehouseId: 2, quantity: 10, createdAt: now(), updatedAt: now() },
  { id: 6, productId: 2, warehouseId: 3, quantity: 80, createdAt: now(), updatedAt: now() },
  { id: 7, productId: 5, warehouseId: 1, quantity: 12, createdAt: now(), updatedAt: now() },
  { id: 8, productId: 1, warehouseId: 4, quantity: 30, createdAt: now(), updatedAt: now() },
  { id: 9, productId: 6, warehouseId: 5, quantity: 50, createdAt: now(), updatedAt: now() },
  { id: 10, productId: 7, warehouseId: 6, quantity: 500, createdAt: now(), updatedAt: now() },
]

const orders: Order[] = [
  { id: 1, enterpriseId: 1, type: 'purchase', supplierId: 1, warehouseId: 1, status: 'received', totalAmount: 12750, notes: 'Q4 restock order', createdBy: 2, createdAt: now(), updatedAt: now() },
  { id: 2, enterpriseId: 1, type: 'purchase', supplierId: 2, warehouseId: 1, status: 'pending', totalAmount: 0, notes: 'Awaiting approval', createdBy: 3, createdAt: now(), updatedAt: now() },
  { id: 3, enterpriseId: 1, type: 'sales', supplierId: null, warehouseId: 1, status: 'shipped', totalAmount: 6499.95, notes: 'Corporate client order', createdBy: 4, createdAt: now(), updatedAt: now() },
  { id: 4, enterpriseId: 2, type: 'purchase', supplierId: null, warehouseId: 5, status: 'approved', totalAmount: 11999.80, notes: 'Software licenses restock', createdBy: 5, createdAt: now(), updatedAt: now() },
]

const orderItems: OrderItem[] = [
  { id: 1, orderId: 1, productId: 1, warehouseId: 1, quantity: 10, unitPrice: 850, createdAt: now(), updatedAt: now() },
  { id: 2, orderId: 1, productId: 2, warehouseId: 1, quantity: 50, unitPrice: 25, createdAt: now(), updatedAt: now() },
  { id: 3, orderId: 3, productId: 1, warehouseId: 1, quantity: 5, unitPrice: 1299.99, createdAt: now(), updatedAt: now() },
  { id: 4, orderId: 4, productId: 6, warehouseId: 5, quantity: 20, unitPrice: 599.99, createdAt: now(), updatedAt: now() },
]

const auditLogs: AuditLog[] = [
  { id: 1, userId: 1, enterpriseId: null, action: 'enterprise.create', entity: 'Enterprise', entityId: 1, details: 'Created Acme Corporation', createdAt: now() },
  { id: 2, userId: 2, enterpriseId: 1, action: 'product.create', entity: 'Product', entityId: 1, details: 'Created Laptop Pro 15"', createdAt: now() },
  { id: 3, userId: 3, enterpriseId: 1, action: 'order.create', entity: 'Order', entityId: 2, details: 'Created purchase order', createdAt: now() },
]

// ─── In-Memory Batches & StockOut Data ─────────────────────

const batches: Batch[] = [
  {
    id: 1, enterpriseId: 1, warehouseId: 1, batchCode: 'BATCH-2024-001',
    supplierId: 1, personName: 'John Smith', personPhone: '+1-555-0101', personEmail: 'john@techcorp.com',
    notes: 'Q4 electronics shipment', status: 'closed',
    entries: [
      { id: 1, batchId: 1, productId: 1, warehouseId: 1, quantity: 30, unit: 'pcs', costPerUnit: 850, notes: 'Laptops - Grade A', createdAt: now(), updatedAt: now() },
      { id: 2, batchId: 1, productId: 2, warehouseId: 1, quantity: 200, unit: 'pcs', costPerUnit: 25, notes: 'Keyboards - Bulk', createdAt: now(), updatedAt: now() },
    ],
    createdAt: now(), updatedAt: now(),
  },
  {
    id: 2, enterpriseId: 1, warehouseId: 1, batchCode: 'BATCH-2024-002',
    supplierId: 2, personName: 'Sarah Chen', personPhone: '+1-555-0202', personEmail: 'sarah@globalmat.com',
    notes: 'Furniture delivery', status: 'open',
    entries: [
      { id: 3, batchId: 2, productId: 3, warehouseId: 1, quantity: 10, unit: 'pcs', costPerUnit: 200, notes: 'Standing desks', createdAt: now(), updatedAt: now() },
    ],
    createdAt: now(), updatedAt: now(),
  },
]

const stockOutRecorders: StockOutRecorder[] = [
  {
    id: 1, enterpriseId: 1, warehouseId: 1, recorderCode: 'OUT-2024-001',
    personName: 'Client Corp Ltd', personPhone: '+1-555-9001', personEmail: 'orders@clientcorp.com',
    personAddress: '500 Corporate Blvd, NY', notes: 'Corporate quarterly order',
    status: 'confirmed',
    items: [
      { id: 1, recorderId: 1, productId: 1, warehouseId: 1, quantity: 5, unit: 'pcs', isReturnable: true, returnDeadline: '2025-03-01', notes: 'Rental units', createdAt: now() },
      { id: 2, recorderId: 1, productId: 2, warehouseId: 1, quantity: 20, unit: 'pcs', isReturnable: false, returnDeadline: null, notes: 'Consumable', createdAt: now() },
    ],
    createdBy: 2, createdAt: now(), updatedAt: now(),
  },
  {
    id: 2, enterpriseId: 1, warehouseId: 1, recorderCode: 'OUT-2024-002',
    personName: 'StartupXYZ', personPhone: '+1-555-9002', personEmail: 'procurement@startupxyz.io',
    personAddress: '101 Innovation Way, SF', notes: 'New office setup',
    status: 'draft',
    items: [
      { id: 3, recorderId: 2, productId: 3, warehouseId: 1, quantity: 3, unit: 'pcs', isReturnable: true, returnDeadline: '2025-06-01', notes: 'Office desks - try before buy', createdAt: now() },
    ],
    createdBy: 3, createdAt: now(), updatedAt: now(),
  },
]

// ─── Tenant-Scoped Database Operations ──────────────────────

export const db = {
  // ── Auth ────────────────────────────────────────────────
  auth: {
    /** Login by username + password, returns user if valid */
    login: async (username: string, password: string): Promise<User | null> => {
      const u = users.find(u => u.username === username && u.passwordHash === password && u.isActive)
      return u || null
    },
    /** Get user by ID */
    getUser: async (id: number): Promise<User | null> => {
      return users.find(u => u.id === id) || null
    },
    /** Build AuthContext from user */
    getAuthContext: (user: User): AuthContext => ({
      userId: user.id,
      role: user.role,
      enterpriseId: user.enterpriseId,
      branchId: user.branchId,
      warehouseId: user.warehouseId,
    }),
    /** Check if actor can manage a target user */
    canManageUser: (ctx: AuthContext, target: User): boolean => canManageUser(ctx, target),
  },

  // ── Enterprises ─────────────────────────────────────────
  enterprises: {
    /** List enterprises scoped to the auth context */
    findMany: async (ctx: AuthContext): Promise<Enterprise[]> => {
      if (ctx.role === 'super_admin') return [...enterprises]
      // Non-super admins see only their own enterprise
      const eid = ctx.enterpriseId
      if (!eid) return []
      return enterprises.filter(e => e.id === eid)
    },
    findById: async (ctx: AuthContext, id: number): Promise<Enterprise | null> => {
      const e = enterprises.find(e => e.id === id)
      if (!e) return null
      if (!canAccessEnterprise(ctx, e.id)) return null
      return e
    },
    create: async (ctx: AuthContext, d: Partial<Enterprise>): Promise<Enterprise> => {
      // Only super_admin can create enterprises
      if (ctx.role !== 'super_admin') throw new Error('FORBIDDEN: Only super_admin can create enterprises')
      const e: Enterprise = { id: ++nextId, name: d.name!, code: d.code!, contactEmail: d.contactEmail || '', contactPhone: d.contactPhone || '', address: d.address || '', isActive: d.isActive ?? true, maxBranches: d.maxBranches || 5, maxWarehouses: d.maxWarehouses || 10, maxUsers: d.maxUsers || 25, createdAt: now(), updatedAt: now() }
      enterprises.push(e)
      persist()
      return e
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Enterprise>): Promise<Enterprise> => {
      const i = enterprises.findIndex(e => e.id === id)
      if (i === -1) throw new Error('Not found')
      if (!canAccessEnterprise(ctx, id)) throw new Error('FORBIDDEN: Cannot access this enterprise')
      // Only super_admin can change limits; enterprise_admin can update contact info
      Object.assign(enterprises[i], d, { updatedAt: now() })
      persist()
      return enterprises[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      if (ctx.role !== 'super_admin') throw new Error('FORBIDDEN: Only super_admin can delete enterprises')
      const i = enterprises.findIndex(e => e.id === id)
      if (i !== -1) enterprises.splice(i, 1)
      persist()
    },
  },

  // ── Features ────────────────────────────────────────────
  features: {
    findByEnterprise: async (ctx: AuthContext, eid: number): Promise<EnterpriseFeature[]> => {
      if (!canAccessEnterprise(ctx, eid)) return []
      return features.filter(f => f.enterpriseId === eid)
    },
    setFeature: async (ctx: AuthContext, eid: number, feature: string, enabled: boolean): Promise<EnterpriseFeature> => {
      // Only super_admin can toggle features
      if (ctx.role !== 'super_admin') throw new Error('FORBIDDEN: Only super_admin can toggle enterprise features')
      const i = features.findIndex(f => f.enterpriseId === eid && f.feature === feature)
      if (i !== -1) { features[i].enabled = enabled; persist(); return features[i] }
      const f: EnterpriseFeature = { id: ++nextId, enterpriseId: eid, feature, enabled }
      features.push(f)
      persist()
      return f
    },
  },

  // ── Branches ────────────────────────────────────────────
  branches: {
    findMany: async (ctx: AuthContext, eid?: number): Promise<Branch[]> => {
      const targetEid = eid || ctx.enterpriseId
      if (ctx.role === 'super_admin') {
        return targetEid ? branches.filter(b => b.enterpriseId === targetEid) : [...branches]
      }
      if (!ctx.enterpriseId) return []
      // enterprise_admin sees all branches in their enterprise
      if (ctx.role === 'enterprise_admin') return branches.filter(b => b.enterpriseId === ctx.enterpriseId && (!targetEid || b.enterpriseId === targetEid))
      // branch_admin/warehouse_admin see only their branch
      return branches.filter(b => b.id === ctx.branchId)
    },
    findById: async (ctx: AuthContext, id: number): Promise<Branch | null> => {
      const b = branches.find(b => b.id === id)
      if (!b) return null
      if (!canAccessBranch(ctx, b.enterpriseId, b.id)) return null
      return b
    },
    create: async (ctx: AuthContext, d: Partial<Branch>): Promise<Branch> => {
      // Only super_admin and enterprise_admin can create branches
      if (ctx.role !== 'super_admin' && ctx.role !== 'enterprise_admin') throw new Error('FORBIDDEN: Only super_admin or enterprise_admin can create branches')
      if (ctx.role === 'enterprise_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN: Cannot create branch in another enterprise')
      const b: Branch = { id: ++nextId, enterpriseId: d.enterpriseId!, name: d.name!, code: d.code!, location: d.location || '', managerName: d.managerName || '', managerEmail: d.managerEmail || '', isActive: d.isActive ?? true, createdAt: now(), updatedAt: now() }
      branches.push(b)
      persist()
      return b
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Branch>): Promise<Branch> => {
      const i = branches.findIndex(b => b.id === id)
      if (i === -1) throw new Error('Not found')
      const b = branches[i]
      if (!canAccessBranch(ctx, b.enterpriseId, b.id)) throw new Error('FORBIDDEN: Cannot access this branch')
      Object.assign(branches[i], d, { updatedAt: now() })
      persist()
      return branches[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = branches.findIndex(b => b.id === id)
      if (i === -1) throw new Error('Not found')
      const b = branches[i]
      if (ctx.role !== 'super_admin' && ctx.role !== 'enterprise_admin') throw new Error('FORBIDDEN')
      if (!canAccessBranch(ctx, b.enterpriseId, b.id)) throw new Error('FORBIDDEN')
      branches.splice(i, 1)
      persist()
    },
  },

  // ── Warehouses ─────────────────────────────────────────
  warehouses: {
    findMany: async (ctx: AuthContext, eid?: number, bid?: number): Promise<Warehouse[]> => {
      if (ctx.role === 'super_admin') {
        return warehouses.filter(w => (!eid || w.enterpriseId === eid) && (!bid || w.branchId === bid))
      }
      if (ctx.role === 'enterprise_admin') {
        return warehouses.filter(w => w.enterpriseId === ctx.enterpriseId && (!bid || w.branchId === bid))
      }
      if (ctx.role === 'branch_admin') {
        return warehouses.filter(w => w.branchId === ctx.branchId)
      }
      // warehouse_admin sees only their warehouse
      return warehouses.filter(w => w.id === ctx.warehouseId)
    },
    findById: async (ctx: AuthContext, id: number): Promise<Warehouse | null> => {
      const w = warehouses.find(w => w.id === id)
      if (!w) return null
      if (!canAccessWarehouse(ctx, w.enterpriseId, w.branchId, w.id)) return null
      return w
    },
    create: async (ctx: AuthContext, d: Partial<Warehouse>): Promise<Warehouse> => {
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN: warehouse_admin cannot create warehouses')
      if (ctx.role === 'branch_admin') {
        if (d.branchId !== ctx.branchId) throw new Error('FORBIDDEN: Cannot create warehouse in another branch')
      }
      if (ctx.role === 'enterprise_admin') {
        if (d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN: Cannot create warehouse in another enterprise')
      }
      const w: Warehouse = { id: ++nextId, enterpriseId: d.enterpriseId!, branchId: d.branchId!, name: d.name!, code: d.code!, location: d.location || '', capacity: d.capacity || 0, managerName: d.managerName || '', isActive: d.isActive ?? true, createdAt: now(), updatedAt: now() }
      warehouses.push(w)
      persist()
      return w
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Warehouse>): Promise<Warehouse> => {
      const i = warehouses.findIndex(w => w.id === id)
      if (i === -1) throw new Error('Not found')
      const w = warehouses[i]
      if (!canAccessWarehouse(ctx, w.enterpriseId, w.branchId, w.id)) throw new Error('FORBIDDEN')
      Object.assign(warehouses[i], d, { updatedAt: now() })
      persist()
      return warehouses[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = warehouses.findIndex(w => w.id === id)
      if (i === -1) throw new Error('Not found')
      const w = warehouses[i]
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      if (!canAccessWarehouse(ctx, w.enterpriseId, w.branchId, w.id)) throw new Error('FORBIDDEN')
      warehouses.splice(i, 1)
      persist()
    },
  },

  // ── Users ───────────────────────────────────────────────
  users: {
    findMany: async (ctx: AuthContext, eid?: number, bid?: number): Promise<User[]> => {
      if (ctx.role === 'super_admin') {
        return users.filter(u => (!eid || u.enterpriseId === eid) && (!bid || u.branchId === bid))
      }
      if (ctx.role === 'enterprise_admin') {
        // Enterprise admin sees all users in their enterprise
        return users.filter(u => u.enterpriseId === ctx.enterpriseId && (!bid || u.branchId === bid))
      }
      if (ctx.role === 'branch_admin') {
        // Branch admin sees users in their branch only
        return users.filter(u => u.branchId === ctx.branchId)
      }
      // Warehouse admin sees only themselves
      return users.filter(u => u.id === ctx.userId)
    },
    findById: async (ctx: AuthContext, id: number): Promise<User | null> => {
      const u = users.find(u => u.id === id)
      if (!u) return null
      // Self-view is always allowed
      if (u.id === ctx.userId) return u
      // Otherwise check hierarchy
      if (ctx.role === 'super_admin') return u
      if (ctx.role === 'enterprise_admin' && u.enterpriseId === ctx.enterpriseId) return u
      if (ctx.role === 'branch_admin' && u.branchId === ctx.branchId) return u
      if (ctx.role === 'warehouse_admin' && u.id === ctx.userId) return u
      return null
    },
    create: async (ctx: AuthContext, d: Partial<User>): Promise<User> => {
      // Enforce hierarchy: you can only create users below your level
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN: warehouse_admin cannot create users')
      if (ctx.role === 'branch_admin') {
        // Branch admin can only create warehouse_admins in their branch
        if (d.role !== 'warehouse_admin') throw new Error('FORBIDDEN: branch_admin can only create warehouse_admin users')
        if (d.branchId !== ctx.branchId) throw new Error('FORBIDDEN: Cannot create user in another branch')
        if (d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN: Cannot create user in another enterprise')
      }
      if (ctx.role === 'enterprise_admin') {
        // Enterprise admin can create branch_admin and warehouse_admin in their enterprise
        if (d.role === 'super_admin') throw new Error('FORBIDDEN: Cannot create super_admin')
        if (d.role === 'enterprise_admin') throw new Error('FORBIDDEN: Cannot create peer enterprise_admin')
        if (d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN: Cannot create user in another enterprise')
      }
      const u: User = { id: ++nextId, enterpriseId: d.enterpriseId || null, branchId: d.branchId || null, warehouseId: d.warehouseId || null, username: d.username!, email: d.email!, fullName: d.fullName!, role: d.role!, isActive: d.isActive ?? true, passwordHash: d.passwordHash || 'admin123', createdAt: now(), updatedAt: now() }
      users.push(u)
      persist()
      return u
    },
    update: async (ctx: AuthContext, id: number, d: Partial<User>): Promise<User> => {
      const i = users.findIndex(u => u.id === id)
      if (i === -1) throw new Error('Not found')
      const target = users[i]
      // Self-update is allowed for non-role changes
      if (id === ctx.userId && !d.role) {
        Object.assign(users[i], d, { updatedAt: now() })
        persist()
        return users[i]
      }
      if (!canManageUser(ctx, target)) throw new Error('FORBIDDEN: Cannot manage this user')
      Object.assign(users[i], d, { updatedAt: now() })
      persist()
      return users[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = users.findIndex(u => u.id === id)
      if (i === -1) throw new Error('Not found')
      const target = users[i]
      if (!canManageUser(ctx, target)) throw new Error('FORBIDDEN: Cannot delete this user')
      users.splice(i, 1)
      persist()
    },
  },

  // ── Categories ──────────────────────────────────────────
  categories: {
    findMany: async (ctx: AuthContext, eid?: number): Promise<Category[]> => {
      const targetEid = eid || (ctx.role !== 'super_admin' ? ctx.enterpriseId : undefined)
      if (ctx.role === 'super_admin') return targetEid ? categories.filter(c => c.enterpriseId === targetEid) : [...categories]
      if (!ctx.enterpriseId) return []
      return categories.filter(c => c.enterpriseId === ctx.enterpriseId)
    },
    create: async (ctx: AuthContext, d: Partial<Category>): Promise<Category> => {
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const c: Category = { id: ++nextId, enterpriseId: d.enterpriseId!, name: d.name!, description: d.description || '', createdAt: now(), updatedAt: now() }
      categories.push(c)
      persist()
      return c
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Category>): Promise<Category> => {
      const i = categories.findIndex(c => c.id === id)
      if (i === -1) throw new Error('Not found')
      const c = categories[i]
      if (!canAccessEnterprise(ctx, c.enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      Object.assign(categories[i], d, { updatedAt: now() })
      persist()
      return categories[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = categories.findIndex(c => c.id === id)
      if (i === -1) throw new Error('Not found')
      const c = categories[i]
      if (!canAccessEnterprise(ctx, c.enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin' || ctx.role === 'branch_admin') throw new Error('FORBIDDEN')
      categories.splice(i, 1)
      persist()
    },
  },

  // ── Suppliers ───────────────────────────────────────────
  suppliers: {
    findMany: async (ctx: AuthContext, eid?: number): Promise<Supplier[]> => {
      const targetEid = eid || (ctx.role !== 'super_admin' ? ctx.enterpriseId : undefined)
      if (ctx.role === 'super_admin') return targetEid ? suppliers.filter(s => s.enterpriseId === targetEid) : [...suppliers]
      if (!ctx.enterpriseId) return []
      return suppliers.filter(s => s.enterpriseId === ctx.enterpriseId)
    },
    create: async (ctx: AuthContext, d: Partial<Supplier>): Promise<Supplier> => {
      if (ctx.role === 'warehouse_admin' || ctx.role === 'branch_admin') throw new Error('FORBIDDEN')
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const s: Supplier = { id: ++nextId, enterpriseId: d.enterpriseId!, name: d.name!, contactPerson: d.contactPerson || '', email: d.email || '', phone: d.phone || '', address: d.address || '', createdAt: now(), updatedAt: now() }
      suppliers.push(s)
      persist()
      return s
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Supplier>): Promise<Supplier> => {
      const i = suppliers.findIndex(s => s.id === id)
      if (i === -1) throw new Error('Not found')
      if (!canAccessEnterprise(ctx, suppliers[i].enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin' || ctx.role === 'branch_admin') throw new Error('FORBIDDEN')
      Object.assign(suppliers[i], d, { updatedAt: now() })
      persist()
      return suppliers[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = suppliers.findIndex(s => s.id === id)
      if (i === -1) throw new Error('Not found')
      if (!canAccessEnterprise(ctx, suppliers[i].enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin' || ctx.role === 'branch_admin') throw new Error('FORBIDDEN')
      suppliers.splice(i, 1)
      persist()
    },
  },

  // ── Products ────────────────────────────────────────────
  products: {
    findMany: async (ctx: AuthContext, eid?: number): Promise<Product[]> => {
      const targetEid = eid || (ctx.role !== 'super_admin' ? ctx.enterpriseId : undefined)
      if (ctx.role === 'super_admin') return targetEid ? products.filter(p => p.enterpriseId === targetEid) : [...products]
      if (!ctx.enterpriseId) return []
      return products.filter(p => p.enterpriseId === ctx.enterpriseId)
    },
    findById: async (ctx: AuthContext, id: number): Promise<Product | null> => {
      const p = products.find(p => p.id === id)
      if (!p) return null
      if (!canAccessEnterprise(ctx, p.enterpriseId)) return null
      return p
    },
    create: async (ctx: AuthContext, d: Partial<Product>): Promise<Product> => {
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const p: Product = { id: ++nextId, enterpriseId: d.enterpriseId!, name: d.name!, sku: d.sku!, description: d.description || '', categoryId: d.categoryId || null, price: d.price || 0, cost: d.cost || 0, unit: d.unit || 'pcs', reorderLevel: d.reorderLevel || 0, isActive: d.isActive ?? true, createdAt: now(), updatedAt: now() }
      products.push(p)
      // Audit log
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: d.enterpriseId!, action: 'product.create', entity: 'Product', entityId: p.id, details: `Created product: ${d.name} (${d.sku})`, createdAt: now() })
      persist()
      return p
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Product>): Promise<Product> => {
      const i = products.findIndex(p => p.id === id)
      if (i === -1) throw new Error('Not found')
      if (!canAccessEnterprise(ctx, products[i].enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      Object.assign(products[i], d, { updatedAt: now() })
      persist()
      return products[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = products.findIndex(p => p.id === id)
      if (i === -1) throw new Error('Not found')
      if (!canAccessEnterprise(ctx, products[i].enterpriseId)) throw new Error('FORBIDDEN')
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      products.splice(i, 1)
      persist()
    },
  },

  // ── Stock ───────────────────────────────────────────────
  stock: {
    findMany: async (ctx: AuthContext): Promise<Stock[]> => {
      if (ctx.role === 'super_admin') return [...stock]
      // Get warehouse IDs accessible to this user
      const accessibleWhIds = warehouses
        .filter(w => {
          if (ctx.role === 'enterprise_admin') return w.enterpriseId === ctx.enterpriseId
          if (ctx.role === 'branch_admin') return w.branchId === ctx.branchId
          if (ctx.role === 'warehouse_admin') return w.id === ctx.warehouseId
          return false
        })
        .map(w => w.id)
      return stock.filter(s => accessibleWhIds.includes(s.warehouseId))
    },
    /** Stock-in: add quantity to a product in a warehouse */
    stockIn: async (ctx: AuthContext, d: { productId: number; warehouseId: number; quantity: number }): Promise<Stock> => {
      const wh = warehouses.find(w => w.id === d.warehouseId)
      if (!wh) throw new Error(`Warehouse #${d.warehouseId} not found`)
      const prod = products.find(p => p.id === d.productId)
      if (!prod) throw new Error(`Product #${d.productId} not found. Register the product first before adding stock.`)
      if (ctx.role === 'warehouse_admin' && ctx.warehouseId !== d.warehouseId) throw new Error('FORBIDDEN: Cannot add stock in another warehouse')
      if (ctx.role === 'enterprise_admin' && wh.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      if (ctx.role === 'branch_admin' && wh.branchId !== ctx.branchId) throw new Error('FORBIDDEN')
      if (d.quantity <= 0) throw new Error('Quantity must be positive')
      const i = stock.findIndex(s => s.productId === d.productId && s.warehouseId === d.warehouseId)
      let result: Stock
      if (i !== -1) { stock[i].quantity += d.quantity; stock[i].updatedAt = now(); result = stock[i] }
      else { result = { id: ++nextId, productId: d.productId, warehouseId: d.warehouseId, quantity: d.quantity, createdAt: now(), updatedAt: now() }; stock.push(result) }
      // Audit log (prod already defined above)
      const whName = wh.name
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: wh.enterpriseId, action: 'stock.in', entity: 'Stock', entityId: result.id, details: `Stock in: +${d.quantity} ${prod?.unit || 'pcs'} of ${prod?.name || `Product #${d.productId}`} to ${whName}. New total: ${result.quantity}`, createdAt: now() })
      persist()
      return result
    },
    adjust: async (ctx: AuthContext, d: { productId: number; warehouseId: number; delta: number }): Promise<Stock> => {
      // Check warehouse access
      const wh = warehouses.find(w => w.id === d.warehouseId)
      if (!wh) throw new Error('Warehouse not found')
      if (ctx.role === 'warehouse_admin' && ctx.warehouseId !== d.warehouseId) throw new Error('FORBIDDEN: Cannot adjust stock in another warehouse')
      if (ctx.role === 'enterprise_admin' && wh.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      if (ctx.role === 'branch_admin' && wh.branchId !== ctx.branchId) throw new Error('FORBIDDEN')
      const i = stock.findIndex(s => s.productId === d.productId && s.warehouseId === d.warehouseId)
      let result: Stock
      if (i !== -1) { stock[i].quantity = Math.max(0, stock[i].quantity + d.delta); stock[i].updatedAt = now(); result = stock[i] }
      else { result = { id: ++nextId, productId: d.productId, warehouseId: d.warehouseId, quantity: Math.max(0, d.delta), createdAt: now(), updatedAt: now() }; stock.push(result) }
      // Audit log
      const prod = products.find(p => p.id === d.productId)
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: wh.enterpriseId, action: 'stock.adjust', entity: 'Stock', entityId: result.id, details: `Stock adjust: ${d.delta > 0 ? '+' : ''}${d.delta} ${prod?.unit || 'pcs'} of ${prod?.name || `Product #${d.productId}`} in ${wh.name}. New total: ${result.quantity}`, createdAt: now() })
      persist()
      return result
    },
  },

  // ── Orders ──────────────────────────────────────────────
  orders: {
    findMany: async (ctx: AuthContext, eid?: number): Promise<Order[]> => {
      if (ctx.role === 'super_admin') return eid ? orders.filter(o => o.enterpriseId === eid) : [...orders]
      if (!ctx.enterpriseId) return []
      if (ctx.role === 'enterprise_admin') return orders.filter(o => o.enterpriseId === ctx.enterpriseId)
      if (ctx.role === 'branch_admin') {
        // Branch admin sees orders for warehouses in their branch
        const whIds = warehouses.filter(w => w.branchId === ctx.branchId).map(w => w.id)
        return orders.filter(o => o.enterpriseId === ctx.enterpriseId && o.warehouseId && whIds.includes(o.warehouseId))
      }
      // Warehouse admin sees only their warehouse orders
      return orders.filter(o => o.warehouseId === ctx.warehouseId)
    },
    findById: async (ctx: AuthContext, id: number): Promise<Order | null> => {
      const o = orders.find(o => o.id === id)
      if (!o) return null
      if (ctx.role === 'super_admin') return o
      if (o.enterpriseId !== ctx.enterpriseId) return null
      if (ctx.role === 'branch_admin') {
        const whIds = warehouses.filter(w => w.branchId === ctx.branchId).map(w => w.id)
        if (!o.warehouseId || !whIds.includes(o.warehouseId)) return null
      }
      if (ctx.role === 'warehouse_admin' && o.warehouseId !== ctx.warehouseId) return null
      return o
    },
    create: async (ctx: AuthContext, d: Partial<Order>): Promise<Order> => {
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN: warehouse_admin cannot create orders in this context')
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const o: Order = { id: ++nextId, enterpriseId: d.enterpriseId!, type: d.type!, supplierId: d.supplierId || null, warehouseId: d.warehouseId || null, status: 'pending', totalAmount: 0, notes: d.notes || '', createdBy: ctx.userId, createdAt: now(), updatedAt: now() }
      orders.push(o)
      persist()
      return o
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Order>): Promise<Order> => {
      const i = orders.findIndex(o => o.id === id)
      if (i === -1) throw new Error('Not found')
      const o = orders[i]
      if (ctx.role === 'super_admin') { Object.assign(orders[i], d, { updatedAt: now() }); persist(); return orders[i] }
      if (o.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      Object.assign(orders[i], d, { updatedAt: now() })
      persist()
      return orders[i]
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = orders.findIndex(o => o.id === id)
      if (i === -1) throw new Error('Not found')
      const o = orders[i]
      if (ctx.role !== 'super_admin' && o.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      orders.splice(i, 1)
      persist()
    },
  },

  // ── Order Items ─────────────────────────────────────────
  orderItems: {
    findByOrder: async (ctx: AuthContext, orderId: number): Promise<OrderItem[]> => {
      const o = orders.find(o => o.id === orderId)
      if (!o) return []
      // Verify order access
      if (ctx.role !== 'super_admin' && o.enterpriseId !== ctx.enterpriseId) return []
      return orderItems.filter(oi => oi.orderId === orderId)
    },
    create: async (ctx: AuthContext, d: Partial<OrderItem>): Promise<OrderItem> => {
      const oi: OrderItem = { id: ++nextId, orderId: d.orderId!, productId: d.productId!, warehouseId: d.warehouseId!, quantity: d.quantity!, unitPrice: d.unitPrice!, createdAt: now(), updatedAt: now() }
      orderItems.push(oi)
      persist()
      return oi
    },
  },

  // ── Audit ───────────────────────────────────────────────
  audit: {
    findMany: async (ctx: AuthContext, limit = 50): Promise<AuditLog[]> => {
      if (ctx.role === 'super_admin') return [...auditLogs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, limit)
      if (!ctx.enterpriseId) return []
      return auditLogs.filter(a => a.enterpriseId === ctx.enterpriseId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, limit)
    },
    create: async (ctx: AuthContext, d: Partial<AuditLog>): Promise<AuditLog> => {
      const a: AuditLog = { id: ++nextId, userId: ctx.userId, enterpriseId: ctx.enterpriseId, action: d.action!, entity: d.entity!, entityId: d.entityId || null, details: d.details || '', createdAt: now() }
      auditLogs.push(a)
      persist()
      return a
    },
  },

  // ── Dashboard Stats ─────────────────────────────────────
  stats: {
    getDashboard: async (ctx: AuthContext) => {
      const eid = ctx.role === 'super_admin' ? undefined : ctx.enterpriseId
      const eProds = eid ? products.filter(p => p.enterpriseId === eid) : products
      const eOrders = eid ? orders.filter(o => o.enterpriseId === eid) : orders
      const eBranches = eid ? branches.filter(b => b.enterpriseId === eid) : branches
      const eWarehouses = eid ? warehouses.filter(w => w.enterpriseId === eid) : warehouses
      const eUsers = eid ? users.filter(u => u.enterpriseId === eid) : users

      // Get accessible warehouse IDs
      let accessibleWhIds: number[]
      if (ctx.role === 'super_admin' || ctx.role === 'enterprise_admin') {
        accessibleWhIds = eWarehouses.map(w => w.id)
      } else if (ctx.role === 'branch_admin') {
        accessibleWhIds = warehouses.filter(w => w.branchId === ctx.branchId).map(w => w.id)
      } else {
        accessibleWhIds = ctx.warehouseId ? [ctx.warehouseId] : []
      }

      const accessibleStock = stock.filter(s => accessibleWhIds.includes(s.warehouseId))
      const totalStockValue = accessibleStock.reduce((sum, s) => {
        const p = products.find(pp => pp.id === s.productId)
        return sum + (p ? s.quantity * p.price : 0)
      }, 0)

      const lowStock = eProds.filter(p => {
        if (!p.isActive) return false
        const totalQty = accessibleStock.filter(s => s.productId === p.id).reduce((s, st) => s + st.quantity, 0)
        return totalQty <= p.reorderLevel
      })

      return {
        enterpriseCount: ctx.role === 'super_admin' ? enterprises.length : 1,
        branchCount: eBranches.length,
        warehouseCount: eWarehouses.length,
        userCount: eUsers.length,
        productCount: eProds.length,
        orderCount: eOrders.length,
        pendingOrderCount: eOrders.filter(o => o.status === 'pending').length,
        totalStockValue,
        lowStockProducts: lowStock.map(p => ({
          id: p.id, name: p.name, sku: p.sku, reorderLevel: p.reorderLevel,
          totalQty: accessibleStock.filter(s => s.productId === p.id).reduce((s, st) => s + st.quantity, 0)
        })),
      }
    },
  },

  // ── Batches ────────────────────────────────────────────────
  batches: {
    findMany: async (ctx: AuthContext, eid?: number, wid?: number): Promise<Batch[]> => {
      const targetEid = eid || (ctx.role !== 'super_admin' ? ctx.enterpriseId : undefined)
      let result = batches
      if (ctx.role === 'super_admin') {
        if (targetEid) result = result.filter(b => b.enterpriseId === targetEid)
        if (wid) result = result.filter(b => b.warehouseId === wid)
        return [...result]
      }
      if (!ctx.enterpriseId) return []
      result = result.filter(b => b.enterpriseId === ctx.enterpriseId)
      if (ctx.role === 'branch_admin') {
        const whIds = warehouses.filter(w => w.branchId === ctx.branchId).map(w => w.id)
        result = result.filter(b => whIds.includes(b.warehouseId))
      }
      if (ctx.role === 'warehouse_admin') {
        result = result.filter(b => b.warehouseId === ctx.warehouseId)
      }
      if (wid) result = result.filter(b => b.warehouseId === wid)
      return result
    },
    findById: async (ctx: AuthContext, id: number): Promise<Batch | null> => {
      const b = batches.find(b => b.id === id)
      if (!b) return null
      if (ctx.role !== 'super_admin' && b.enterpriseId !== ctx.enterpriseId) return null
      return b
    },
    create: async (ctx: AuthContext, d: Partial<Batch>): Promise<Batch> => {
      if (ctx.role === 'warehouse_admin') throw new Error('FORBIDDEN')
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const b: Batch = {
        id: ++nextId, enterpriseId: d.enterpriseId!, warehouseId: d.warehouseId!,
        batchCode: d.batchCode || `BATCH-${Date.now()}`, supplierId: d.supplierId || null,
        personName: d.personName || '', personPhone: d.personPhone || '',
        personEmail: d.personEmail || '', notes: d.notes || '',
        status: 'open', entries: [], createdAt: now(), updatedAt: now(),
      }
      batches.push(b)
      persist()
      return b
    },
    update: async (ctx: AuthContext, id: number, d: Partial<Batch>): Promise<Batch> => {
      const i = batches.findIndex(b => b.id === id)
      if (i === -1) throw new Error('Not found')
      if (ctx.role !== 'super_admin' && batches[i].enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      Object.assign(batches[i], d, { updatedAt: now() })
      persist()
      return batches[i]
    },
    addEntry: async (ctx: AuthContext, batchId: number, d: Partial<BatchEntry>): Promise<BatchEntry> => {
      const b = batches.find(b => b.id === batchId)
      if (!b) throw new Error(`Batch #${batchId} not found. It may have been deleted or the ID is invalid.`)
      if (b.status !== 'open') throw new Error(`Cannot add entries to a ${b.status} batch. Only open batches can receive entries.`)
      if (ctx.role !== 'super_admin' && b.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      if (!d.productId) throw new Error('Product is required for batch entry')
      if (!d.warehouseId) throw new Error('Warehouse is required for batch entry')
      const prod = products.find(p => p.id === d.productId)
      if (!prod) throw new Error(`Product #${d.productId} not found`)
      const wh = warehouses.find(w => w.id === d.warehouseId)
      if (!wh) throw new Error(`Warehouse #${d.warehouseId} not found`)
      const qty = d.quantity || 0
      if (qty <= 0) throw new Error('Quantity must be positive')
      const e: BatchEntry = {
        id: ++nextId, batchId, productId: d.productId!, warehouseId: d.warehouseId!,
        quantity: qty, unit: d.unit || 'pcs', costPerUnit: d.costPerUnit || 0,
        notes: d.notes || '', createdAt: now(), updatedAt: now(),
      }
      b.entries.push(e)
      b.updatedAt = now()
      // Immediately update stock: batch entry = stock-in
      const si = stock.findIndex(s => s.productId === d.productId! && s.warehouseId === d.warehouseId!)
      if (si !== -1) {
        stock[si].quantity += qty
        stock[si].updatedAt = now()
      } else {
        const s: Stock = { id: ++nextId, productId: d.productId!, warehouseId: d.warehouseId!, quantity: qty, createdAt: now(), updatedAt: now() }
        stock.push(s)
      }
      // Audit log for batch entry (prod already defined above)
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: b.enterpriseId, action: 'batch.add_entry', entity: 'BatchEntry', entityId: e.id, details: `Batch ${b.batchCode}: Added ${qty} ${d.unit || 'pcs'} of ${prod?.name || `Product #${d.productId}`}. Stock updated.`, createdAt: now() })
      persist()
      return e
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = batches.findIndex(b => b.id === id)
      if (i === -1) throw new Error('Not found')
      if (ctx.role !== 'super_admin' && batches[i].enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      batches.splice(i, 1)
      persist()
    },
  },

  // ── Stock Out Recorders ────────────────────────────────────
  stockOut: {
    findMany: async (ctx: AuthContext, eid?: number, wid?: number): Promise<StockOutRecorder[]> => {
      const targetEid = eid || (ctx.role !== 'super_admin' ? ctx.enterpriseId : undefined)
      let result = stockOutRecorders
      if (ctx.role === 'super_admin') {
        if (targetEid) result = result.filter(r => r.enterpriseId === targetEid)
        if (wid) result = result.filter(r => r.warehouseId === wid)
        return [...result]
      }
      if (!ctx.enterpriseId) return []
      result = result.filter(r => r.enterpriseId === ctx.enterpriseId)
      if (ctx.role === 'branch_admin') {
        const whIds = warehouses.filter(w => w.branchId === ctx.branchId).map(w => w.id)
        result = result.filter(r => whIds.includes(r.warehouseId))
      }
      if (ctx.role === 'warehouse_admin') {
        result = result.filter(r => r.warehouseId === ctx.warehouseId)
      }
      if (wid) result = result.filter(r => r.warehouseId === wid)
      return result
    },
    findById: async (ctx: AuthContext, id: number): Promise<StockOutRecorder | null> => {
      const r = stockOutRecorders.find(r => r.id === id)
      if (!r) return null
      if (ctx.role !== 'super_admin' && r.enterpriseId !== ctx.enterpriseId) return null
      return r
    },
    create: async (ctx: AuthContext, d: Partial<StockOutRecorder>): Promise<StockOutRecorder> => {
      if (ctx.role !== 'super_admin' && d.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const r: StockOutRecorder = {
        id: ++nextId, enterpriseId: d.enterpriseId!, warehouseId: d.warehouseId!,
        recorderCode: d.recorderCode || `OUT-${Date.now()}`,
        personName: d.personName || '', personPhone: d.personPhone || '',
        personEmail: d.personEmail || '', personAddress: d.personAddress || '',
        notes: d.notes || '',
        status: 'draft', items: [],
        createdBy: ctx.userId, createdAt: now(), updatedAt: now(),
      }
      stockOutRecorders.push(r)
      persist()
      return r
    },
    update: async (ctx: AuthContext, id: number, d: Partial<StockOutRecorder>): Promise<StockOutRecorder> => {
      const i = stockOutRecorders.findIndex(r => r.id === id)
      if (i === -1) throw new Error('Not found')
      if (ctx.role !== 'super_admin' && stockOutRecorders[i].enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      Object.assign(stockOutRecorders[i], d, { updatedAt: now() })
      persist()
      return stockOutRecorders[i]
    },
    addItem: async (ctx: AuthContext, recorderId: number, d: Partial<StockOutItem>): Promise<StockOutItem> => {
      const r = stockOutRecorders.find(r => r.id === recorderId)
      if (!r) throw new Error(`Stock-out recorder #${recorderId} not found. It may have been deleted.`)
      if (ctx.role !== 'super_admin' && r.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const qty = d.quantity || 0
      if (qty <= 0) throw new Error('Quantity must be positive')
      if (!d.productId) throw new Error('Product is required')
      if (!d.warehouseId) throw new Error('Warehouse is required')
      // Check and deduct stock
      const si = stock.findIndex(s => s.productId === d.productId! && s.warehouseId === d.warehouseId!)
      if (si === -1) {
        const prod = products.find(p => p.id === d.productId)
        const wh = warehouses.find(w => w.id === d.warehouseId)
        throw new Error(`No stock found for ${prod?.name || `product #${d.productId}`} in ${wh?.name || `warehouse #${d.warehouseId}`}. Add stock first before stock-out.`)
      }
      if (stock[si].quantity < qty) throw new Error(`Insufficient stock: only ${stock[si].quantity} available for ${products.find(p=>p.id===d.productId)?.name||`product #${d.productId}`}, requested ${qty}`)
      stock[si].quantity -= qty
      stock[si].updatedAt = now()
      const item: StockOutItem = {
        id: ++nextId, recorderId, productId: d.productId!, warehouseId: d.warehouseId!,
        quantity: qty, unit: d.unit || 'pcs',
        isReturnable: d.isReturnable ?? false, returnDeadline: d.returnDeadline || null,
        notes: d.notes || '', createdAt: now(),
      }
      r.items.push(item)
      r.updatedAt = now()
      // Audit log
      const prod = products.find(p => p.id === d.productId!)
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: r.enterpriseId, action: 'stock_out.add_item', entity: 'StockOutItem', entityId: item.id, details: `Stock out ${qty} ${d.unit || 'pcs'} of ${prod?.name || `Product #${d.productId}`} from warehouse #${d.warehouseId} (recorder #${recorderId}). Stock was ${stock[si].quantity + qty}, now ${stock[si].quantity}`, createdAt: now() })
      persist()
      return item
    },
    /** Remove a stock-out item and RESTORE the deducted stock */
    removeItem: async (ctx: AuthContext, recorderId: number, itemId: number): Promise<void> => {
      const r = stockOutRecorders.find(r => r.id === recorderId)
      if (!r) throw new Error(`Stock-out recorder #${recorderId} not found`)
      if (ctx.role !== 'super_admin' && r.enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const itemIdx = r.items.findIndex(i => i.id === itemId)
      if (itemIdx === -1) throw new Error(`Item #${itemId} not found in recorder #${recorderId}`)
      const item = r.items[itemIdx]
      const prod = products.find(p => p.id === item.productId)
      // Restore the stock that was deducted
      const si = stock.findIndex(s => s.productId === item.productId && s.warehouseId === item.warehouseId)
      if (si !== -1) {
        stock[si].quantity += item.quantity
        stock[si].updatedAt = now()
      } else {
        // If stock entry was deleted somehow, create it back
        stock.push({ id: ++nextId, productId: item.productId, warehouseId: item.warehouseId, quantity: item.quantity, createdAt: now(), updatedAt: now() })
      }
      r.items.splice(itemIdx, 1)
      r.updatedAt = now()
      // Audit log
      auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: r.enterpriseId, action: 'stock_out.remove_item', entity: 'StockOutItem', entityId: itemId, details: `Removed stock-out item: restored ${item.quantity} ${item.unit} of ${prod?.name || `Product #${item.productId}`} to warehouse #${item.warehouseId}. Stock restored.`, createdAt: now() })
      persist()
    },
    remove: async (ctx: AuthContext, id: number): Promise<void> => {
      const i = stockOutRecorders.findIndex(r => r.id === id)
      if (i === -1) throw new Error(`Stock-out recorder #${id} not found`)
      if (ctx.role !== 'super_admin' && stockOutRecorders[i].enterpriseId !== ctx.enterpriseId) throw new Error('FORBIDDEN')
      const r = stockOutRecorders[i]
      // Restore stock for all items in the recorder being deleted
      // (Unlike cancellation, deletion implies the recorder was made in error)
      for (const item of r.items) {
        const si = stock.findIndex(s => s.productId === item.productId && s.warehouseId === item.warehouseId)
        if (si !== -1) {
          stock[si].quantity += item.quantity
          stock[si].updatedAt = now()
        } else {
          stock.push({ id: ++nextId, productId: item.productId, warehouseId: item.warehouseId, quantity: item.quantity, createdAt: now(), updatedAt: now() })
        }
      }
      if (r.items.length > 0) {
        auditLogs.push({ id: ++nextId, userId: ctx.userId, enterpriseId: r.enterpriseId, action: 'stock_out.delete_recorder', entity: 'StockOutRecorder', entityId: id, details: `Deleted recorder ${r.recorderCode} and restored ${r.items.length} item(s) to stock`, createdAt: now() })
      }
      stockOutRecorders.splice(i, 1)
      persist()
    },
  },
}

// Re-export scoping helpers for use in API routes
export { canAccessEnterprise, canAccessBranch, canAccessWarehouse, canManageUser }

// ─── Load persisted data on startup ────────────────────────
loadPersisted()
