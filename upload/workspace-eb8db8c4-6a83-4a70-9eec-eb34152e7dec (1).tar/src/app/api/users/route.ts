import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function GET(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const eid = req.nextUrl.searchParams.get('eid')
    const bid = req.nextUrl.searchParams.get('bid')
    const data = await db.users.findMany(ctx, eid ? parseInt(eid) : undefined, bid ? parseInt(bid) : undefined)
    return NextResponse.json(data)
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}

export async function POST(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const body = await req.json()
    const data = await db.users.create(ctx, body)
    return NextResponse.json(data)
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
