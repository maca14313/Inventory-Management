import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> }
) {
  try {
    const { id, itemId } = await params
    const ctx = getAuthContextFromHeaders(req.headers)
    await db.stockOut.removeItem(ctx, parseInt(id), parseInt(itemId))
    return NextResponse.json({ success: true })
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
