import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const ctx = getAuthContextFromHeaders(req.headers)
    const body = await req.json()
    const data = await db.stockOut.addItem(ctx, parseInt(id), body)
    return NextResponse.json(data)
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
