import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const user = await db.auth.login(body.username, body.password)
    if (!user) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    return NextResponse.json({
      id: user.id, username: user.username, fullName: user.fullName,
      email: user.email, role: user.role,
      enterpriseId: user.enterpriseId, branchId: user.branchId,
      warehouseId: user.warehouseId, isActive: user.isActive,
    })
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}
