import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const data = await db.suppliers.findMany(ctx)
    const item = data.find(s => s.id === parseInt(params.id))
    if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json(item)
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const body = await req.json()
    const allSuppliers = await db.suppliers.findMany(ctx)
    const item = allSuppliers.find(s => s.id === parseInt(params.id))
    if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    // Use internal update
    const { db: dbDirect } = await import('@/lib/db')
    const data = await dbDirect.suppliers.update(ctx, parseInt(params.id), body)
    return NextResponse.json(data)
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const { db: dbDirect } = await import('@/lib/db')
    await dbDirect.suppliers.remove(ctx, parseInt(params.id))
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
