import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function GET(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const data = await db.stock.findMany(ctx)
    return NextResponse.json(data)
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}

export async function POST(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const body = await req.json()
    // Route based on action: "stockIn" uses the stockIn method, otherwise adjust (delta)
    if (body.action === 'stockIn') {
      const data = await db.stock.stockIn(ctx, { productId: body.productId, warehouseId: body.warehouseId, quantity: body.quantity })
      return NextResponse.json(data)
    }
    const data = await db.stock.adjust(ctx, body)
    return NextResponse.json(data)
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
