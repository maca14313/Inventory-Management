import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function GET(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const data = await db.enterprises.findMany(ctx)
    return NextResponse.json(data)
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}

export async function POST(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const body = await req.json()
    const data = await db.enterprises.create(ctx, body)
    return NextResponse.json(data)
  } catch (e: any) {
    if (e.message.startsWith('FORBIDDEN')) return NextResponse.json({ error: e.message }, { status: 403 })
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
