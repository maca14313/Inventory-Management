import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthContextFromHeaders } from '@/lib/api'

export async function GET(req: NextRequest) {
  try {
    const ctx = getAuthContextFromHeaders(req.headers)
    const data = await db.audit.findMany(ctx)
    return NextResponse.json(data)
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }) }
}
