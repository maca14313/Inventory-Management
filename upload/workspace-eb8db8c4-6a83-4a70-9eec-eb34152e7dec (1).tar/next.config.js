/** @type {import('next').NextConfig} */
const nextConfig = {
  // basePath and NEXT_PUBLIC_BASE_PATH are set during production build for cPanel deployment
  // For local dev, they are empty (app served at root /)
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

module.exports = nextConfig;
