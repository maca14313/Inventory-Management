# Next.js cPanel Deployment Guide

> A general guide for developing Next.js apps with the fullstack skill and deploying them to cPanel (CloudLinux + LiteSpeed + Phusion Passenger).

---

## Part 1 — Develop with the Fullstack Skill

### Why Use the Fullstack Skill?

The fullstack skill gives you a **live preview** of your app while you build it. You can see every change immediately in the browser without manually starting servers or running builds. This means you iterate faster — add a feature, see it, fix it, see the fix — all before you ever create a production build.

### The Workflow

```
1. Initialize   →  fullstack-dev skill sets up the project
2. Develop      →  write code, see it live in the Preview Panel
3. Iterate      →  add features, fix bugs, redesign — all with live preview
4. Say "build"  →  only then create the production build and deployment package
```

**Key rule: do not finalize or build until the user explicitly says "build".** Until then, keep developing and let them see changes in the preview.

### Step-by-Step

#### 1. Initialize the Project

Invoke the `fullstack-dev` skill. It runs an init script that:

- Sets up a Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui project
- Starts the dev server on port 3000
- Opens the Preview Panel so the user can see the app

```bash
# The skill runs this automatically:
curl https://z-cdn.chatglm.cn/fullstack/init-fullstack.sh | bash
```

The dev server (`next dev -p 3000`) starts in the background and hot-reloads on every file change.

#### 2. Write Code — See It Live

The fullstack skill provides:

| What | Details |
|------|---------|
| Framework | Next.js 16 with App Router |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui components |
| Dev server | Auto-runs on port 3000, hot-reloads |
| Preview | Visible in the Preview Panel (right side of the interface) |

All shadcn/ui components are already in `src/components/ui/` — use them directly instead of building from scratch.

**Important rules for the dev environment:**

- The user can only see the `/` route (`src/app/page.tsx`). Do not write other routes for the preview.
- Use `agent-browser` to self-verify: open the page, click buttons, confirm the UI works.
- Do NOT run `bun run build` or `bun run dev` manually — the system manages the dev server.
- For API requests to other ports, use `?XTransformPort=<port>` (never write ports directly in URLs).

#### 3. Database in Dev vs. Production

During development in the sandbox, you typically do not have access to the production MySQL database. Use one of these strategies:

| Strategy | How | When to use |
|----------|-----|-------------|
| **In-memory fallback** | Detect if MySQL env vars are missing → fall back to an array-based store | Simple CRUD apps, quick prototyping |
| **Local SQLite** | Use Prisma with SQLite for dev, MySQL for prod | Apps that need real query behavior in dev |
| **Mock API** | Hardcode sample data in the API routes | Frontend-heavy apps where DB logic is minimal |

The **in-memory fallback** is the simplest and most reliable approach for sandbox preview. It means the app works immediately without any database setup, and when deployed to production with MySQL env vars set, it automatically uses the real database.

#### 4. Iterate Until Ready

Add features, fix styling, adjust UX — the user sees every change live. Only move to Part 2 when the user says **"build"**.

---

## Part 2 — Build for Production and Deploy to cPanel

### What Makes cPanel Different

cPanel with CloudLinux + LiteSpeed + Passenger has several constraints that break standard Next.js deployments if you don't account for them:

| Constraint | Why it matters | The fix |
|------------|----------------|---------|
| **Phusion Passenger** | Passenger intercepts `.listen()` — your server must export the handler, not call listen directly | Use `http.createServer` and call `.listen()` — Passenger overrides it automatically |
| **CloudLinux virtual env** | `node_modules` must be a symlink managed by CloudLinux, not a real folder you upload | Exclude `node_modules` from the deployment archive; use cPanel "Run NPM Install" instead |
| **Node.js version** | CloudLinux NodeJS Selector defaults to Node 10, which is too old for Next.js 16 (requires 18.6+) | Recreate the app in cPanel with **Node.js 20** |
| **Subpath deployment** | Apps deployed at `/myapp` need Next.js to prepend `/myapp` to all routes and assets | Set `basePath: '/myapp'` in `next.config.js` |
| **Turbopack ignores `.ts` config** | If you use `next.config.ts`, Turbopack will not read `basePath` | Use `next.config.js` (CommonJS) instead |
| **Client fetch() needs manual prefix** | `fetch('/api/...')` goes to the root domain, not `/myapp/api/...` | Add `NEXT_PUBLIC_BASE_PATH` env var and prefix all fetch URLs with it |
| **No native modules** | Modules like `better-sqlite3` that compile C++ code fail on CloudLinux | Use `mysql2/promise` only (pure JS + native bindings that work) |

### Deployment Checklist

Follow these steps in order. Each step references the constraint it solves.

---

#### Step 1: Configure `next.config.js` (NOT `.ts`)

Turbopack (Next.js 16's default compiler) ignores `basePath` from TypeScript config files. You must use a `.js` CommonJS file.

```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Set this to your cPanel subpath (e.g. '/todo', '/myapp')
  // Leave empty for root deployment
  basePath: '/myapp',

  // Expose basePath to client-side code for fetch() URL prefixing
  env: {
    NEXT_PUBLIC_BASE_PATH: '/myapp',
  },

  // Skip type checking during build (faster, avoids CI-only type errors)
  typescript: {
    ignoreBuildErrors: true,
  },

  reactStrictMode: false,
};

module.exports = nextConfig;
```

> **For local dev**: Set `basePath` to empty string (`''`) so the app runs at `/`. Only set it to the subpath when building for production. Alternatively, keep it empty in the config file and set it via environment variable at build time.

---

#### Step 2: Write `server.js` with Node's `http` Module (NOT Express)

Passenger expects a Node.js server that calls `.listen()`. It intercepts the call and binds to its own socket. Using Express causes `Cannot find module 'express'` errors because Express is not a runtime dependency in the minimal deploy package.

```js
const { createServer } = require('http')
const next = require('next')

const app = next({ dev: false })
const handle = app.getRequestHandler()
const port = parseInt(process.env.PORT, 10) || 3000

app.prepare().then(() => {
  createServer((req, res) => {
    handle(req, res)
  }).listen(port, () => {
    console.log(`[server] Ready on port ${port}`)
  })
}).catch((err) => {
  console.error('[server] Failed to start:', err)
  process.exit(1)
})
```

**Why `http.createServer` and not Express?**
- Zero extra dependencies — Node's `http` is built-in
- Passenger works with it directly
- No risk of missing module errors in production

---

#### Step 3: Database — Use `mysql2/promise` Only

Do NOT use:
- `better-sqlite3` — C++ native module, fails on CloudLinux
- `@prisma/client` with native engine — engine binary may not match CloudLinux's glibc version
- Any ORM that requires native compilation

Use `mysql2/promise` directly. It is pure JavaScript with native bindings that work universally.

**Database connection pattern** — support both `DATABASE_URL` and individual env vars (cPanel style):

```ts
import mysql from 'mysql2/promise'

let pool: mysql.Pool | null = null

function getPool(): mysql.Pool {
  if (pool) return pool

  const url = process.env.DATABASE_URL
  if (url && url.startsWith('mysql://')) {
    // Option A: Single connection string
    pool = mysql.createPool(url)
  } else if (process.env.DB_USER) {
    // Option B: Individual vars (cPanel standard)
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME,
      waitForConnections: true,
      connectionLimit: 10,
    })
  } else {
    throw new Error('No MySQL config. Set DB_HOST+DB_USER+DB_PASSWORD+DB_NAME or DATABASE_URL.')
  }
  return pool
}
```

**Auto-create tables** — run `CREATE TABLE IF NOT EXISTS` on first API request so no manual SQL setup is needed:

```ts
let tableReady = false

async function ensureTable(): Promise<void> {
  if (tableReady) return
  await getPool().execute(`
    CREATE TABLE IF NOT EXISTS MyTable (
      id        INT AUTO_INCREMENT PRIMARY KEY,
      -- your columns here
      createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
    )
  `)
  tableReady = true
}
```

---

#### Step 4: Prefix Client-Side Fetch URLs

Next.js `basePath` automatically prefixes `<Link>`, `<Image>`, and `<Script>` — but it does **not** prefix `fetch()` calls. You must do it manually.

In your page components:

```tsx
const BASE = process.env.NEXT_PUBLIC_BASE_PATH || ''

// Then use it in every fetch call:
const res = await fetch(`${BASE}/api/items`)
const res = await fetch(`${BASE}/api/items`, { method: 'POST', ... })
```

The `NEXT_PUBLIC_BASE_PATH` env var is set in `next.config.js` (Step 1), so it's embedded at build time. In local dev it's empty (`''`), so fetches go to `/api/...`. In production it's `/myapp`, so fetches go to `/myapp/api/...`.

---

#### Step 5: Build Locally

Run the production build on your local machine (or in the sandbox):

```bash
npm install
npm run build
```

This creates the `.next/` directory with the compiled app.

---

#### Step 6: Create the Deployment Archive

Create a tar.gz (or zip) with **only these items**:

```
server.js
package.json          ← the minimal runtime one (see below)
next.config.js
.next/               ← the compiled build
public/              ← static assets
```

**Do NOT include:**
- `node_modules/` — CloudLinux rejects real folders; it must be a symlink managed by the system
- `.env` — use cPanel environment variables instead
- `src/` — already compiled into `.next/`
- `prisma/` — not needed at runtime if using mysql2 directly

**Minimal `package.json` for deployment** — include only runtime dependencies:

```json
{
  "dependencies": {
    "next": "16.1.3",
    "react": "19.2.3",
    "react-dom": "19.2.3",
    "mysql2": "3.23.2"
  }
}
```

Add any shadcn/ui radix packages your app actually uses (e.g., `@radix-ui/react-checkbox`, `@radix-ui/react-toast`, `lucide-react`, etc.). The full list depends on your app's components.

**Create the archive:**

```bash
tar -czf myapp.tar.gz \
  server.js \
  package.json \
  next.config.js \
  .next/ \
  public/
```

---

#### Step 7: Upload to cPanel

1. Go to **cPanel → File Manager**
2. Navigate to your app's directory (e.g., `~/myapp/`)
3. Upload `myapp.tar.gz`
4. Extract it

---

#### Step 8: Configure the Node.js App in cPanel

Go to **cPanel → Software → Setup Node.js App**

| Setting | Value |
|---------|-------|
| **Node.js version** | **20** (NOT 10 — Next.js 16 requires 18.6+) |
| **Application root** | `myapp` |
| **Application URL** | your domain/subdomain |
| **Application startup file** | `server.js` |

**Add environment variables:**

| Variable | Value |
|----------|-------|
| `DB_HOST` | `localhost` |
| `DB_USER` | your MySQL username |
| `DB_PASSWORD` | your MySQL password |
| `DB_NAME` | your MySQL database name |
| `NODE_ENV` | `production` |

> Do NOT create a `.env` file. cPanel env vars are the correct way.

**Then:**
1. Click **Run NPM Install** — this creates the CloudLinux-managed `node_modules` symlink
2. Click **Start** (or **Restart**)

---

#### Step 9: Verify

Visit your app URL (e.g., `https://yourdomain.com/myapp`). You should see the app working with data from MySQL.

If you get errors, check the Passenger log in cPanel:
- **cPanel → Software → Setup Node.js App → your app → View Logs**

---

## Part 3 — Common Errors and Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `SyntaxError: Unexpected token ?` | Node.js 10 selected in cPanel | Recreate the app with **Node.js 20** |
| `404 This page could not be found` | Missing `basePath` for subpath deployment | Add `basePath: '/myapp'` to `next.config.js` |
| `basePath` not applied (assets at `/_next/` not `/myapp/_next/`) | Using `next.config.ts` — Turbopack ignores it | Rename to `next.config.js` (CommonJS) |
| `Failed to load todos` / API 404 | Client `fetch('/api/...')` missing basePath prefix | Use `${BASE}/api/...` with `NEXT_PUBLIC_BASE_PATH` |
| `Cannot find module 'express'` | `server.js` uses Express but it's not in deploy deps | Rewrite `server.js` to use `http.createServer` |
| `Cannot find module 'better-sqlite3'` | SQLite bundled in build but not installed on server | Remove all SQLite code; use `mysql2/promise` only |
| 503 Service Unavailable | App crashed on startup | Check Passenger logs; usually a missing module or Node version issue |
| `node_modules` rejected by CloudLinux | Real `node_modules` folder uploaded | Delete it; use cPanel "Run NPM Install" instead |

---

## Part 4 — Quick Reference: File Structure

### Development (in sandbox with fullstack skill)

```
my-project/
├── src/
│   ├── app/
│   │   ├── page.tsx          ← main page (the only route visible in preview)
│   │   ├── layout.tsx
│   │   ├── globals.css
│   │   └── api/
│   │       └── items/
│   │           ├── route.ts       ← GET, POST
│   │           └── [id]/
│   │               └── route.ts   ← PUT, DELETE
│   ├── lib/
│   │   └── db.ts              ← database driver (mysql2 + in-memory fallback)
│   └── components/
│       └── ui/                ← shadcn/ui components
├── next.config.js             ← basePath config (empty in dev)
├── package.json               ← full dev deps
└── server.js                  ← not used in dev (Next.js dev server handles it)
```

### Deployment (production on cPanel)

```
myapp/
├── server.js                  ← entry point for Passenger
├── next.config.js             ← with basePath: '/myapp'
├── package.json               ← minimal runtime deps only
├── .next/                     ← compiled build output
│   ├── static/
│   └── server/
└── public/                    ← static assets
```

---

## Summary

| Phase | Tool | Action |
|-------|------|--------|
| **Develop** | Fullstack skill | Write code, see it live in Preview Panel, iterate |
| **Build** | `npm run build` | Compile the app locally with `basePath` set |
| **Package** | `tar -czf` | Archive server.js + package.json + .next/ + public/ (no node_modules) |
| **Deploy** | cPanel File Manager | Upload archive, extract |
| **Configure** | cPanel Node.js App | Set Node 20, server.js, env vars, Run NPM Install, Start |
| **Verify** | Browser | Visit the URL, test CRUD, check logs if broken |

The key insight: **develop with live preview first, build only when ready**. This catches UI bugs, logic errors, and styling issues before they reach production — where debugging is much harder.
