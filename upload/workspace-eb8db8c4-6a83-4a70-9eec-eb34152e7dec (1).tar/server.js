/**
 * server.js — Next.js + Passenger/LiteSpeed (cPanel + CloudLinux)
 *
 * No Express needed. Uses raw http.Server.
 * Passenger intercepts .listen() at runtime.
 * CloudLinux handles node_modules as a symlink via NodeJS Selector.
 */

const { createServer } = require('http')
const next = require('next')

const app = next({ dev: false })
const handle = app.getRequestHandler()

const port = parseInt(process.env.PORT, 10) || 3000

app.prepare().then(() => {
  createServer((req, res) => {
    handle(req, res)
  }).listen(port, () => {
    console.log(`[server] Ready on port ${port}`)
  })
}).catch((err) => {
  console.error('[server] Failed to start:', err)
  process.exit(1)
})
