import json

page = r''''use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  LayoutDashboard, Package, Warehouse as WHIcon, Users, ShoppingCart, Tag,
  Plus, Trash2, Pencil, Search, AlertTriangle, TrendingUp,
  Box, Truck, Building2, GitBranch, Shield, Globe, LogOut, Loader2,
  Key, Lock, ToggleLeft, ToggleRight, Menu, X, ChevronDown, ChevronRight,
  ClipboardList, ArrowUpFromLine, RotateCcw, Calendar, Check, Eye, LayoutGrid, List,
} from 'lucide-react'
import { toast } from '@/hooks/use-toast'
import { t, type Locale, locales } from '@/lib/i18n'
import {
  type RoleLevel, type Permission, type EnterpriseAbility,
  ROLE_HIERARCHY, ROLE_LABELS, ROLE_DESCRIPTIONS,
  ALL_ABILITIES, ABILITY_LABELS,
  PERMISSION_GROUPS, MANAGEABLE_ROLES,
  hasPermission, canManageRole, getPermissions, getNavItemsForRole,
} from '@/lib/rbac'
import { useAuthStore } from '@/lib/auth-store'
import { apiFetch } from '@/lib/api'
import { MEASUREMENTS } from '@/lib/db'

const BASE = process.env.NEXT_PUBLIC_BASE_PATH || ''
const SORTED_MEASUREMENTS = [...MEASUREMENTS].sort((a, b) => a.localeCompare(b))

const ICONS: Record<string, React.ComponentType<any>> = {
  LayoutDashboard, Package, Warehouse: WHIcon, Users, ShoppingCart, Tag,
  Box, Truck, Building2, GitBranch, Shield, Globe, ClipboardList, ArrowUpFromLine,
}

interface Enterprise { id: number; name: string; code: string; contactEmail: string; contactPhone: string; address: string; isActive: boolean; maxBranches: number; maxWarehouses: number; maxUsers: number }
interface Branch { id: number; enterpriseId: number; name: string; code: string; location: string; managerName: string; managerEmail: string; isActive: boolean }
interface Warehouse { id: number; enterpriseId: number; branchId: number; name: string; code: string; location: string; capacity: number; managerName: string; isActive: boolean }
interface User { id: number; enterpriseId: number | null; branchId: number | null; warehouseId: number | null; username: string; email: string; fullName: string; role: RoleLevel; isActive: boolean }
interface Category { id: number; enterpriseId: number; name: string; description: string }
interface Supplier { id: number; enterpriseId: number; name: string; contactPerson: string; email: string; phone: string; address: string }
interface Product { id: number; enterpriseId: number; name: string; sku: string; description: string; categoryId: number | null; price: number; cost: number; unit: string; reorderLevel: number; isActive: boolean }
interface StockItem { id: number; productId: number; warehouseId: number; quantity: number }
interface Order { id: number; enterpriseId: number; type: 'purchase' | 'sales'; supplierId: number | null; warehouseId: number | null; status: string; totalAmount: number; notes: string; createdBy: number | null }
interface AuditEntry { id: number; userId: number | null; enterpriseId: number | null; action: string; entity: string; entityId: number | null; details: string; createdAt: string }
interface Feature { id: number; enterpriseId: number; feature: string; enabled: boolean }
interface BatchEntry { id: number; batchId: number; productId: number; warehouseId: number; quantity: number; unit: string; costPerUnit: number; notes: string }
interface Batch { id: number; enterpriseId: number; warehouseId: number; batchCode: string; supplierId: number | null; personName: string; personPhone: string; personEmail: string; notes: string; status: string; entries: BatchEntry[] }
interface StockOutItem { id: number; recorderId: number; productId: number; warehouseId: number; quantity: number; unit: string; unitPrice: number; isReturnable: boolean; returnDeadline: string | null; notes: string }
interface StockOutRecorder { id: number; enterpriseId: number; warehouseId: number; recorderCode: string; personName: string; personPhone: string; personEmail: string; personAddress: string; notes: string; taxRate: number; status: string; items: StockOutItem[] }
interface DashboardStats { enterpriseCount: number; branchCount: number; warehouseCount: number; userCount: number; productCount: number; orderCount: number; pendingOrderCount: number; totalStockValue: number; lowStockProducts: { id: number; name: string; sku: string; reorderLevel: number; totalQty: number }[] }

export default function IMSApp() {
  const auth = useAuthStore()
  const [locale, setLocale] = useState<Locale>('en')
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [loginUser, setLoginUser] = useState('superadmin')
  const [loginPass, setLoginPass] = useState('admin123')
  const [loginLoading, setLoginLoading] = useState(false)

  const [enterprises, setEnterprises] = useState<Enterprise[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [warehouses, setWarehouses] = useState<Warehouse[]>([])
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [stockData, setStockData] = useState<StockItem[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [auditData, setAuditData] = useState<AuditEntry[]>([])
  const [features, setFeatures] = useState<Feature[]>([])
  const [batchData, setBatchData] = useState<Batch[]>([])
  const [stockOutData, setStockOutData] = useState<StockOutRecorder[]>([])
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(false)

  const [dlgOpen, setDlgOpen] = useState(false)
  const [dlgType, setDlgType] = useState('')
  const [dlgData, setDlgData] = useState<any>({})
  const [dlgEdit, setDlgEdit] = useState<any>(null)
  const [stockOutMode, setStockOutMode] = useState<'pic' | 'table'>('pic')
  const [expandedBatch, setExpandedBatch] = useState<number | null>(null)
  const [expandedOut, setExpandedOut] = useState<number | null>(null)

  const role = auth.role
  const eid = auth.enterpriseId

  const handleLogin = useCallback(async () => {
    setLoginLoading(true)
    try {
      const res = await fetch(`${BASE}/api/auth`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: loginUser, password: loginPass }) })
      const data = await res.json()
      if (!res.ok) { toast({ title: data.error || 'Login failed', variant: 'destructive' }); setLoginLoading(false); return }
      auth.login(data); setPage('dashboard'); toast({ title: `Welcome, ${data.fullName}` })
    } catch (e: any) { toast({ title: e.message, variant: 'destructive' }) }
    setLoginLoading(false)
  }, [loginUser, loginPass, auth])

  const loadData = useCallback(async () => {
    if (!auth.isLoggedIn) return
    setLoading(true)
    try {
      const h = { 'Content-Type': 'application/json', ...auth.getAuthHeaders() }
      const f = (url: string) => fetch(`${BASE}/api${url}`, { headers: h }).then(r => r.json()).catch(() => [])
      const [s, e, b, w, u, c, sup, p, st, o, a, feat, bat, so] = await Promise.all([
        f('/dashboard'), f('/enterprises'), f('/branches'), f('/warehouses'), f('/users'),
        f('/categories'), f('/suppliers'), f('/products'), f('/stock'), f('/orders'),
        f('/audit'), f('/features'), f('/batches'), f('/stock-out'),
      ])
      setStats(s); setEnterprises(e); setBranches(b); setWarehouses(w)
      setAllUsers(u); setCategories(c); setSuppliers(sup); setProducts(p)
      setStockData(st); setOrders(o); setAuditData(a); setFeatures(feat)
      setBatchData(bat); setStockOutData(so)
    } catch (e: any) { console.error(e) }
    setLoading(false)
  }, [auth.isLoggedIn, auth.userId, auth.role, auth.enterpriseId, auth.branchId, auth.warehouseId])

  useEffect(() => { if (auth.isLoggedIn) loadData() }, [auth.isLoggedIn, auth.userId])

  const crud = {
    create: async (ep: string, d: any) => { try { await apiFetch(ep, { method: 'POST', body: JSON.stringify(d) }); toast({ title: t(locale, 'created') }); loadData() } catch (e: any) { toast({ title: e.message, variant: 'destructive' }) } },
    update: async (ep: string, d: any) => { try { await apiFetch(ep, { method: 'PUT', body: JSON.stringify(d) }); toast({ title: t(locale, 'updated') }); loadData() } catch (e: any) { toast({ title: e.message, variant: 'destructive' }) } },
    remove: async (ep: string) => { try { await apiFetch(ep, { method: 'DELETE' }); toast({ title: t(locale, 'deleted') }); loadData() } catch (e: any) { toast({ title: e.message, variant: 'destructive' }) } },
  }

  const openCreate = (type: string) => { setDlgType(type); setDlgEdit(null); setDlgData({}); setDlgOpen(true) }
  const openEdit = (type: string, item: any) => { setDlgType(type); setDlgEdit(item); setDlgData({ ...item }); setDlgOpen(true) }

  const fmt = (n: number) => new Intl.NumberFormat(locale, { style: 'currency', currency: 'USD' }).format(n)
  const fmtN = (n: number) => new Intl.NumberFormat(locale).format(n)
  const statusBadge = (status: string) => {
    const c: Record<string, string> = { received: 'bg-green-500/20 text-green-400', approved: 'bg-blue-500/20 text-blue-400', pending: 'bg-yellow-500/20 text-yellow-400', shipped: 'bg-cyan-500/20 text-cyan-400', cancelled: 'bg-red-500/20 text-red-400', draft: 'bg-slate-500/20 text-slate-400', confirmed: 'bg-emerald-500/20 text-emerald-400', open: 'bg-yellow-500/20 text-yellow-400', closed: 'bg-green-500/20 text-green-400', partial_return: 'bg-orange-500/20 text-orange-400', returned: 'bg-blue-500/20 text-blue-400' }
    return <Badge className={`${c[status] || 'bg-slate-500/20 text-slate-400'} border-0`}>{status.replace(/_/g,' ')}</Badge>
  }

  const navItems = getNavItemsForRole(role!).concat([
    { key: 'batches', label: 'Batches', icon: 'ClipboardList', href: '/batches', permission: 'stock:view' as Permission },
    { key: 'stockOut', label: 'Stock Out', icon: 'ArrowUpFromLine', href: '/stock-out', permission: 'orders:view' as Permission },
    { key: 'features', label: 'Features', icon: 'ToggleLeft', href: '/features', permission: 'enterprises:set_features' as Permission },
  ]).filter((v, i, a) => a.findIndex(x => x.key === v.key) === i)

  // ─── LOGIN SCREEN ──────────────────────────────────────
  if (!auth.isLoggedIn) {
    const dir = locales.find(l => l.code === locale)?.dir || 'ltr'
    return (
      <div dir={dir} className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-3 sm:p-4">
        <Card className="w-full max-w-md border-slate-700 bg-slate-800/80 backdrop-blur">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto mb-2 w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center"><Box className="w-7 h-7 text-white" /></div>
            <CardTitle className="text-xl sm:text-2xl text-white">{t(locale, 'loginTitle')}</CardTitle>
            <Card>CardDescription className="text-slate-400">{t(locale, 'loginSubtitle')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2"><Label className="text-slate-300">Username</Label><Input value={loginUser} onChange={e => setLoginUser(e.target.value)} className="bg-slate-700 border-slate-600 text-white" /></div>
            <div className="space-y-2"><Label className="text-slate-300">{t(locale, 'labelPassword')}</Label><Input type="password" value={loginPass} onChange={e => setLoginPass(e.target.value)} className="bg-slate-700 border-slate-600 text-white" /></div>
            <Button onClick={handleLogin} disabled={loginLoading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">{loginLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Key className="w-4 h-4 mr-2" />}{t(locale, 'loginButton')}</Button>
            <Separator className="bg-slate-600" />
            <div className="space-y-2"><Label className="text-slate-400 text-xs">Demo Accounts (password: admin123)</Label>
              <div className="space-y-1.5">{[
                { u: 'superadmin', label: 'Super Admin', desc: 'Full system access' },
                { u: 'acmeadmin', label: 'Enterprise Admin', desc: 'Acme Corporation' },
                { u: 'northadmin', label: 'Branch Admin', desc: 'Acme North Division' },
                { u: 'bostonwh', label: 'Warehouse Admin', desc: 'Boston Main WH' },
              ].map(d => (
                <button key={d.u} onClick={() => { setLoginUser(d.u); setLoginPass('admin123') }}
                  className={`w-full text-left px-3 py-2 rounded-lg border transition-all text-sm ${loginUser === d.u ? 'bg-blue-600/30 border-blue-500 text-blue-300' : 'bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700'}`}>
                  <span className="font-medium">{d.label}</span><span className="text-slate-500 ml-2">— {d.desc}</span>
                </button>
              ))}</div>
            </div>
            <div className="flex gap-2 justify-center pt-2">{locales.map(l => (
              <button key={l.code} onClick={() => setLocale(l.code)} className={`px-2 py-1 rounded text-xs transition ${locale === l.code ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}>{l.name}</button>
            ))}</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const dir = locales.find(l => l.code === locale)?.dir || 'ltr'

  // ─── PAGE CONTENT RENDERER ─────────────────────────────
  const renderPage = () => {
    if (loading) return <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-blue-400" /><span className="ml-3 text-slate-400">{t(locale, 'loading')}</span></div>

    // DASHBOARD
    if (page === 'dashboard') return (
      <div className="space-y-4 sm:space-y-6">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navDashboard')}</h1><Badge className="bg-slate-800 text-slate-400 border-0">{ROLE_LABELS[role!]}</Badge></div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {stats && [
            { key: 'enterpriseCount', label: t(locale, 'kpiEnterprises'), icon: Building2, color: 'text-purple-400', show: role === 'super_admin' },
            { key: 'branchCount', label: t(locale, 'kpiBranches'), icon: GitBranch, color: 'text-orange-400', show: true },
            { key: 'warehouseCount', label: t(locale, 'kpiWarehouses'), icon: WHIcon, color: 'text-cyan-400', show: true },
            { key: 'userCount', label: 'Users', icon: Users, color: 'text-green-400', show: true },
            { key: 'productCount', label: t(locale, 'kpiProducts'), icon: Package, color: 'text-blue-400', show: true },
            { key: 'orderCount', label: t(locale, 'navOrders'), icon: ShoppingCart, color: 'text-yellow-400', show: true },
            { key: 'pendingOrderCount', label: t(locale, 'kpiPendingOrders'), icon: AlertTriangle, color: 'text-red-400', show: true },
            { key: 'totalStockValue', label: t(locale, 'kpiStockValue'), icon: TrendingUp, color: 'text-emerald-400', show: true },
          ].filter(k => k.show).map(k => (
            <Card key={k.key} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3"><k.icon className={`w-4 h-4 sm:w-5 sm:h-5 ${k.color}`} />
                <div><div className="text-lg sm:text-2xl font-bold">{k.key === 'totalStockValue' ? fmt(stats[k.key as keyof DashboardStats] as number) : fmtN(stats[k.key as keyof DashboardStats] as number)}</div>
                  <div className="text-[10px] sm:text-xs text-slate-500">{k.label}</div></div>
              </div></CardContent></Card>
          ))}
        </div>
        {stats && stats.lowStockProducts.length > 0 && (
          <Card className="bg-slate-900 border-slate-800"><CardHeader><CardTitle className="text-red-400 flex items-center gap-2 text-sm sm:text-base"><AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5" /> {t(locale, 'lowStockAlerts')}</CardTitle></CardHeader>
          <CardContent><div className="space-y-2">{stats.lowStockProducts.map(p => (
            <div key={p.id} className="flex flex-col sm:flex-row sm:items-center justify-between text-sm bg-slate-800/50 rounded-lg px-3 py-2 gap-1">
              <span>{p.name} <span className="text-slate-500">({p.sku})</span></span>
              <div className="flex items-center gap-3 sm:gap-4"><span className="text-slate-500">{t(locale, 'current')}: <span className="text-red-400 font-bold">{p.totalQty}</span></span><span className="text-slate-500">{t(locale, 'reorderLevel')}: {p.reorderLevel}</span></div>
            </div>))}</div></CardContent></Card>
        )}
      </div>
    )

    // ENTERPRISES
    if (page === 'enterprises' && hasPermission(role!, 'enterprises:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navEnterprises')}</h1>
          {hasPermission(role!, 'enterprises:create') && <Button onClick={() => openCreate('enterprise')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newEnterprise')}</Button>}</div>
        <div className="grid gap-3">{enterprises.map(e => (
          <Card key={e.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div><div className="font-semibold">{e.name} <Badge className="ml-2 bg-slate-700 text-slate-300 border-0">{e.code}</Badge></div>
              <div className="text-xs text-slate-500 mt-1">{e.address}</div>
              <div className="text-xs text-slate-600">Branches: {e.maxBranches} · WH: {e.maxWarehouses} · Users: {e.maxUsers}</div></div>
            <div className="flex gap-2">{hasPermission(role!, 'enterprises:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('enterprise', e)} className="text-slate-400"><Pencil className="w-4 h-4" /></Button>}
              {hasPermission(role!, 'enterprises:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/enterprises/${e.id}`)} className="text-red-400"><Trash2 className="w-4 h-4" /></Button>}</div>
          </CardContent></Card>))}</div>
      </div>
    )

    // BRANCHES
    if (page === 'branches' && hasPermission(role!, 'branches:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navBranches')}</h1>
          {hasPermission(role!, 'branches:create') && <Button onClick={() => openCreate('branch')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newBranch')}</Button>}</div>
        <div className="grid gap-3">{branches.map(b => (
          <Card key={b.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div><div className="font-semibold">{b.name} <Badge className="ml-2 bg-slate-700 text-slate-300 border-0">{b.code}</Badge></div>
              <div className="text-xs text-slate-500 mt-1">{b.location} · {b.managerName}</div></div>
            <div className="flex gap-2">{hasPermission(role!, 'branches:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('branch', b)} className="text-slate-400"><Pencil className="w-4 h-4" /></Button>}
              {hasPermission(role!, 'branches:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/branches/${b.id}`)} className="text-red-400"><Trash2 className="w-4 h-4" /></Button>}</div>
          </CardContent></Card>))}</div>
      </div>
    )

    // WAREHOUSES
    if (page === 'warehouses' && hasPermission(role!, 'warehouses:view')) return (
      <div className="space-y-4">
       Gh1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navWarehouses')}</h1>
          {hasPermission(role!, 'warehouses:create') && <Button onClick={() => openCreate('warehouse')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newWarehouse')}</Button>}</div>
        <div className="grid gap-3">{warehouses.map(w => (
          <Card key={w.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div><div className="font-semibold">{w.name} <Badge className="ml-2 bg-slate-700 text-slate-300 border-0">{w.code}</Badge></div>
              <div className="text-xs text-slate-500 mt-1">{w.location} · Cap: {fmtN(w.capacity)}</div></div>
            <div className="flex gap-2">{hasPermission(role!, 'warehouses:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('warehouse', w)} className="text-slate-400"><Pencil className="w-4 h-4" /></Button>}
              {hasPermission(role!, 'warehouses:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/warehouses/${w.id}`)} className="text-red-400"><Trash2 className="w-4 h-4" /></Button>}</div>
          </CardContent></Card>))}</div>
      </div>
    )

    // USERS
    if (page === 'users' && hasPermission(role!, 'users:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navUsers')}</h1>
          {hasPermission(role!, 'users:create') && <Button onClick={() => openCreate('user')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newUser')}</Button>}</div>
        <div className="space-y-2">{allUsers.map(u => (
          <Card key={u.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold">{u.fullName.charAt(0)}</div>
              <div><div className="font-medium text-sm">{u.fullName}</div><div className="text-xs text-slate-500">{u.username} · {u.email}</div></div></div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className={`${u.role === 'super_admin' ? 'bg-purple-500/20 text-purple-400' : u.role === 'enterprise_admin' ? 'bg-blue-500/20 text-blue-400' : u.role === 'branch_admin' ? 'bg-orange-500/20 text-orange-400' : 'bg-cyan-500/20 text-cyan-400'} border-0`}>{ROLE_LABELS[u.role]}</Badge>
              {hasPermission(role!, 'users:edit') && (role === 'super_admin' || canManageRole(role!, u.role)) && <Button size="sm" variant="ghost" onClick={() => openEdit('user', u)} className="text-slate-400"><Pencil className="w-3.5 h-3.5" /></Button>}
            </div></CardContent></Card>))}</div>
        <Card className="bg-slate-900 border-slate-800"><CardHeader><CardTitle className="text-xs flex items-center gap-2"><Lock className="w-4 h-4 text-blue-400" /> Hierarchy</CardTitle></CardHeader>
          <CardContent className="text-xs text-slate-500"><p>Role: <span className="text-blue-400">{ROLE_LABELS[role!]}</span></p><p>Can create: <span className="text-slate-300">{MANAGEABLE_ROLES[role!].map(r => ROLE_LABELS[r]).join(', ') || 'None'}</span></p></CardContent></Card>
      </div>
    )

    // PRODUCTS
    if (page === 'products' && hasPermission(role!, 'products:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navProducts')}</h1>
          {hasPermission(role!, 'products:create') && <Button onClick={() => openCreate('product')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newProduct')}</Button>}</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{products.map(p => {
          const cat = categories.find(c => c.id === p.categoryId)
          return (<Card key={p.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
            <div className="flex items-start justify-between"><div><div className="font-semibold text-sm">{p.name}</div><div className="text-xs text-slate-500 font-mono">{p.sku}</div></div>
              <div className="flex gap-1">{hasPermission(role!, 'products:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('product', p)} className="text-slate-400 h-7 w-7 p-0"><Pencil className="w-3 h-3" /></Button>}
                {hasPermission(role!, 'products:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/products/${p.id}`)} className="text-red-400 h-7 w-7 p-0"><Trash2 className="w-3 h-3" /></Button>}</div></div>
            <div className="mt-2 text-xs text-slate-500">{cat?.name || '—'}</div>
            <div className="mt-1 flex items-center gap-3"><span className="text-sm font-bold text-emerald-400">{fmt(p.price)}</span><span className="text-xs text-slate-600">Cost: {fmt(p.cost)}</span></div>
            <div className="text-xs text-slate-600">Reorder: {p.reorderLevel} · Unit: {p.unit}</div>
          </CardContent></Card>)})}</div>
      </div>
    )

    // STOCK
    if (page === 'stock' && hasPermission(role!, 'stock:view')) return (
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navStock')}</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{stockData.map(s => {
          const prod = products.find(p => p.id === s.productId); const wh = warehouses.find(w => w.id === s.warehouseId); const isLow = prod ? s.quantity <= prod.reorderLevel : false
          return (<Card key={s.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between"><div><div className="font-semibold text-sm">{prod?.name || `Product #${s.productId}`}</div><div className="text-xs text-slate-500">{wh?.name || `WH #${s.warehouseId}`}</div></div>
              {isLow ? <Badge className="bg-red-500/20 text-red-400 border-0">Low</Badge> : <Badge className="bg-green-500/20 text-green-400 border-0">OK</Badge>}</div>
            <div className="mt-2 flex items-center gap-3"><span className="text-lg font-bold">{s.quantity}</span><span className="text-xs text-slate-500">Value: {prod ? fmt(s.quantity * prod.price) : '—'}</span></div>
            {hasPermission(role!, 'stock:adjust') && <Button size="sm" variant="outline" onClick={() => openEdit('stock', s)} className="mt-2 text-blue-400 border-slate-700 text-xs">Adjust</Button>}
          </CardContent></Card>)})}</div>
      </div>
    )

    // ORDERS
    if (page === 'orders' && hasPermission(role!, 'orders:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navOrders')}</h1>
          {hasPermission(role!, 'orders:create') && <Button onClick={() => openCreate('order')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newOrder')}</Button>}</div>
        <div className="grid gap-3">{orders.map(o => { const wh = warehouses.find(w => w.id === o.warehouseId)
          return (<Card key={o.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="font-mono text-sm">#{o.id}</span>{statusBadge(o.status)}
              <Badge className={`${o.type === 'purchase' ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400'} border-0`}>{o.type}</Badge></div>
              <span className="text-sm font-bold">{fmt(o.totalAmount)}</span></div>
            <div className="mt-1 text-xs text-slate-500">{wh?.name || '—'} · {o.notes}</div>
            {hasPermission(role!, 'orders:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('order', o)} className="mt-1 text-slate-400 text-xs"><Pencil className="w-3 h-3 mr-1" />Edit</Button>}
          </CardContent></Card>)})}</div>
      </div>
    )

    // SUPPLIERS
    if (page === 'suppliers' && hasPermission(role!, 'suppliers:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navSuppliers')}</h1>
          {hasPermission(role!, 'suppliers:create') && <Button onClick={() => openCreate('supplier')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newSupplier')}</Button>}</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{suppliers.map(s => (
          <Card key={s.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
            <div className="font-semibold text-sm">{s.name}</div><div className="text-xs text-slate-500 mt-1">{s.contactPerson} · {s.email}</div><div className="text-xs text-slate-600">{s.phone}</div>
            <div className="flex gap-2 mt-2">{hasPermission(role!, 'suppliers:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('supplier', s)} className="text-slate-400"><Pencil className="w-3 h-3" /></Button>}
              {hasPermission(role!, 'suppliers:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/suppliers/${s.id}`)} className="text-red-400"><Trash2 className="w-3 h-3" /></Button>}</div>
          </CardContent></Card>))}</div>
      </div>
    )

    // CATEGORIES
    if (page === 'categories' && hasPermission(role!, 'categories:view')) return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold">{t(locale, 'navCategories')}</h1>
          {hasPermission(role!, 'categories:create') && <Button onClick={() => openCreate('category')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />{t(locale, 'newCategory')}</Button>}</div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">{categories.map(c => (
          <Card key={c.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3">
            <div className="font-semibold text-sm">{c.name}</div><div className="text-xs text-slate-500 mt-1">{c.description}</div>
            <div className="flex gap-2 mt-2">{hasPermission(role!, 'categories:edit') && <Button size="sm" variant="ghost" onClick={() => openEdit('category', c)} className="text-slate-400 h-6 w-6 p-0"><Pencil className="w-3 h-3" /></Button>}
              {hasPermission(role!, 'categories:delete') && <Button size="sm" variant="ghost" onClick={() => crud.remove(`/categories/${c.id}`)} className="text-red-400 h-6 w-6 p-0"><Trash2 className="w-3 h-3" /></Button>}</div>
          </CardContent></Card>))}</div>
      </div>
    )

    // BATCHES
    if (page === 'batches') return (
      <div className="space-y-4">
        <div className="flex items-center justify-between"><h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2"><ClipboardList className="w-5 h-5 text-blue-400" /> Inventory Batches</h1>
          <Button onClick={() => openCreate('batch')} className="bg-blue-600 hover:bg-blue-700 text-sm"><Plus className="w-4 h-4 mr-1" />New Batch</Button></div>
        <div className="grid gap-3">{batchData.map(b => { const wh = warehouses.find(w => w.id === b.warehouseId); const isExp = expandedBatch === b.id
          return (<Card key={b.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between cursor-pointer" onClick={() => setExpandedBatch(isExp ? null : b.id)}>
              <div className="flex items-center gap-2"><ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${isExp ? 'rotate-90' : ''}`} />
                <div><div className="font-semibold text-sm">{b.batchCode} {statusBadge(b.status)}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{b.personName} · {wh?.name || '—'} · {b.entries.length} entries</div></div></div>
              <span className="text-xs text-slate-600">{new Date(b.createdAt).toLocaleDateString()}</span></div>
            {isExp && (<div className="mt-3 space-y-2 border-t border-slate-800 pt-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs"><div className="text-slate-500">Phone: <span className="text-slate-300">{b.personPhone || '—'}</span></div><div className="text-slate-500">Email: <span className="text-slate-300">{b.personEmail || '—'}</span></div></div>
              {b.notes && <div className="text-xs text-slate-500">Notes: {b.notes}</div>}
              <div className="space-y-1.5">{b.entries.map(e => { const prod = products.find(p => p.id === e.productId)
                return (<div key={e.id} className="bg-slate-800/60 rounded-lg p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div><div className="text-sm font-medium">{prod?.name || `Product #${e.productId}`}</div><div className="text-xs text-slate-500">{e.notes}</div></div>
                  <div className="flex items-center gap-3 text-xs"><span>Qty: <span className="font-bold">{e.quantity}</span> {e.unit}</span><span>Cost: {fmt(e.costPerUnit)}/{e.unit}</span><span className="text-slate-600">Total: {fmt(e.quantity * e.costPerUnit)}</span></div>
                </div>)})}</div>
              <Button size="sm" variant="outline" onClick={() => openCreate('batchEntry')} className="text-blue-400 border-slate-700 text-xs mt-1"><Plus className="w-3 h-3 mr-1" />Add Entry</Button>
            </div>)}
          </CardContent></Card>)})}</div>
      </div>
    )

    // STOCK OUT RECORDER
    if (page === 'stockOut') return (
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2"><ArrowUpFromLine className="w-5 h-5 text-orange-400" /> Stock Out Recorder</h1>
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-800 rounded-lg p-0.5"><button onClick={() => setStockOutMode('pic')} className={`p-1.5 rounded-md transition ${stockOutMode === 'pic' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}><LayoutGrid className="w-4 h-4" /></button>
              <button onClick={() => setStockOutMode('table')} className={`p-1.5 rounded-md transition ${stockOutMode === 'table' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}><List className="w-4 h-4" /></button></div>
            <Button onClick={() => openCreate('stockOut')} className="bg-orange-600 hover:bg-orange-700 text-sm"><Plus className="w-4 h-4 mr-1" />New</Button></div></div>
        {/* Group by person */}
        {(() => { const grouped = stockOutData.reduce((acc, r) => { const key = r.personName || 'Unknown'; if (!acc[key]) acc[key] = []; acc[key].push(r); return acc }, {} as Record<string, StockOutRecorder[]>)
          return Object.entries(grouped).map(([person, recs]) => (
            <div key={person} className="space-y-2">
              <div className="flex items-center gap-2 px-1"><div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 text-sm font-bold">{person.charAt(0)}</div>
                <div><div className="font-semibold text-sm">{person}</div>{recs[0]?.personPhone && <div className="text-xs text-slate-500">{recs[0].personPhone} · {recs[0].personEmail}</div>}</div></div>
              {recs.map(r => { const isExp = expandedOut === r.id
                return (<Card key={r.id} className="bg-slate-900 border-slate-800"><CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between cursor-pointer" onClick={() => setExpandedOut(isExp ? null : r.id)}>
                    <div className="flex items-center gap-2"><ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${isExp ? 'rotate-90' : ''}`} />
                      <div><div className="font-semibold text-sm">{r.recorderCode} {statusBadge(r.status)}</div>
                        <div className="text-xs text-slate-500 mt-0.5">{r.items.length} items · Tax: {(r.taxRate * 100).toFixed(0)}%</div></div></div>
                    <span className="text-xs text-slate-600">{new Date(r.createdAt).toLocaleDateString()}</span></div>
                  {isExp && (<div className="mt-3 space-y-2 border-t border-slate-800 pt-3">
                    {r.personAddress && <div className="text-xs text-slate-500">Address: {r.personAddress}</div>}
                    {r.notes && <div className="text-xs text-slate-500">Notes: {r.notes}</div>}
                    {stockOutMode === 'pic' ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">{r.items.map(item => { const prod = products.find(p => p.id === item.productId)
                        return (<Card key={item.id} className="bg-slate-800/60 border-slate-700"><CardContent className="p-3">
                          <div className="flex items-start justify-between"><Package className="w-8 h-8 text-blue-400" />
                            <div className="flex items-center gap-1">{item.isReturnable ? <Badge className="bg-green-500/20 text-green-400 border-0 text-[10px]"><RotateCcw className="w-3 h-3 mr-0.5" />Returnable</Badge> : <Badge className="bg-red-500/20 text-red-400 border-0 text-[10px]">Non-return</Badge>}</div></div>
                          <div className="mt-2"><div className="font-medium text-sm">{prod?.name || `Product #${item.productId}`}</div>
                            <div className="text-xs text-slate-500">{item.quantity} {item.unit} × {fmt(item.unitPrice)}</div>
                            <div className="text-sm font-bold text-emerald-400 mt-1">{fmt(item.quantity * item.unitPrice)}</div>
                            {item.returnDeadline && <div className="text-xs text-slate-500 mt-1 flex items-center gap-1"><Calendar className="w-3 h-3" />Return by: {item.returnDeadline}</div>}
                            {item.notes && <div className="text-xs text-slate-600 mt-0.5">{item.notes}</div>}</div>
                        </CardContent></Card>)})}</div>
                    ) : (
                      <div className="overflow-x-auto -mx-3 sm:mx-0"><table className="w-full text-xs min-w-[500px]">
                        <thead className="bg-slate-800/50"><tr><th className="px-2 py-2 text-left text-slate-400">Product</th><th className="px-2 py-2 text-right text-slate-400">Qty</th><th className="px-2 py-2 text-left text-slate-400">Unit</th><th className="px-2 py-2 text-right text-slate-400">Price</th><th className="px-2 py-2 text-right text-slate-400">Total</th><th className="px-2 py-2 text-center text-slate-400">Return</th><th className="px-2 py-2 text-left text-slate-400">Deadline</th></tr></thead>
                        <tbody>{r.items.map(item => { const prod = products.find(p => p.id === item.productId)
                          return (<tr key={item.id} className="border-t border-slate-800"><td className="px-2 py-1.5">{prod?.name || `#${item.productId}`}</td><td className="px-2 py-1.5 text-right font-mono">{item.quantity}</td><td className="px-2 py-1.5">{item.unit}</td><td className="px-2 py-1.5 text-right">{fmt(item.unitPrice)}</td><td className="px-2 py-1.5 text-right font-bold">{fmt(item.quantity * item.unitPrice)}</td>
                            <td className="px-2 py-1.5 text-center">{item.isReturnable ? <RotateCcw className="w-3 h-3 text-green-400 inline" /> : <X className="w-3 h-3 text-red-400 inline" />}</td><td className="px-2 py-1.5 text-slate-500">{item.returnDeadline || '—'}</td></tr>)})}</tbody></table></div>
                    )}
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800">
                      <div className="text-xs text-slate-500">Subtotal: <span className="font-bold text-slate-300">{fmt(r.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0))}</span>
                        {r.taxRate > 0 && <> · Tax: <span className="text-orange-400">{fmt(r.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0) * r.taxRate)}</span></>}</div>
                      <Button size="sm" variant="outline" onClick={() => openCreate('stockOutItem')} className="text-blue-400 border-slate-700 text-xs"><Plus className="w-3 h-3 mr-1" />Add Item</Button></div>
                  </div>)}
                </CardContent></Card>)})}</div>))})()}
      </div>
    )

    // FEATURES
    if (page === 'features') return (
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2"><ToggleLeft className="w-5 h-5 text-blue-400" /> Enterprise Features</h1>
        {role !== 'super_admin' && <Card className="bg-yellow-500/10 border-yellow-500/30"><CardContent className="p-3 text-xs text-yellow-400"><Lock className="w-4 h-4 inline mr-1" />Only Super Admin can toggle features</CardContent></Card>}
        {enterprises.map(e => { const eFeats = features.filter(f => f.enterpriseId === e.id)
          return (<Card key={e.id} className="bg-slate-900 border-slate-800"><CardHeader><CardTitle className="text-sm">{e.name} <Badge className="ml-2 bg-slate-700 text-slate-300 border-0">{e.code}</Badge></CardTitle></CardHeader>
            <CardContent><div className="grid grid-cols-1 sm:grid-cols-2 gap-2">{eFeats.map(f => (
              <div key={f.id} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-2.5">
                <span className="text-sm capitalize">{f.feature.replace(/_/g, ' ')}</span>
                {role === 'super_admin' ? <Switch checked={f.enabled} onCheckedChange={async (v) => { try { await apiFetch('/features', { method: 'POST', body: JSON.stringify({ enterpriseId: e.id, feature: f.feature, enabled: v }) }); loadData() } catch(e: any) { toast({ title: e.message, variant: 'destructive' }) } }} /> : <Badge className={`${f.enabled ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'} border-0`}>{f.enabled ? 'On' : 'Off'}</Badge>}
              </div>))}</div></CardContent></Card>)})}
      </div>
    )

    // AUDIT
    if (page === 'audit') return (
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-bold">Audit Log</h1>
        <div className="space-y-1.5">{auditData.map(a => { const user = allUsers.find(u => u.id === a.userId)
          return (<div key={a.id} className="bg-slate-900 rounded-lg border border-slate-800 p-2.5 sm:p-3 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
            <span className="text-xs text-slate-500 whitespace-nowrap">{new Date(a.createdAt).toLocaleString()}</span>
            <span className="text-xs text-slate-400">{user?.fullName || `User #${a.userId}`}</span>
            <span className="font-mono text-xs text-blue-400">{a.action}</span>
            <span className="text-xs text-slate-500">{a.entity}</span>
            <span className="text-xs text-slate-600 truncate">{a.details}</span></div>)})}</div>
      </div>
    )

    return null
  }

  // ─── MAIN LAYOUT ────────────────────────────────────────
  return (
    <TooltipProvider>
      <div dir={dir} className="min-h-screen bg-slate-950 text-slate-100 flex">
        {/* Mobile overlay */}
        {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

        {/* Sidebar */}
        <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform lg:static lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="p-3 sm:p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center"><Box className="w-4 h-4 text-white" /></div>
              <div><div className="font-semibold text-xs">{t(locale, 'appName')}</div><div className="text-[10px] text-slate-500">{t(locale, 'appSubtitle')}</div></div></div>
            <button className="lg:hidden text-slate-500" onClick={() => setSidebarOpen(false)}><X className="w-5 h-5" /></button></div>

          <div className="px-3 sm:px-4 py-2.5 border-b border-slate-800">
            <div className="flex items-center gap-2 mb-0.5"><Shield className="w-3 h-3 text-blue-400" /><span className="text-[10px] sm:text-xs font-medium text-blue-400">{ROLE_LABELS[role!]}</span></div>
            <div className="text-[10px] sm:text-xs text-slate-500 truncate">{auth.fullName}</div>
            {eid && <div className="text-[10px] text-slate-600">E#{eid}{auth.branchId ? ` B#${auth.branchId}` : ''}{auth.warehouseId ? ` W#${auth.warehouseId}` : ''}</div>}</div>

          <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {navItems.map(item => { const Icon = ICONS[item.icon] || Box; const active = page === item.key
              return (<button key={item.key} onClick={() => { setPage(item.key); setSidebarOpen(false) }}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs sm:text-sm transition-all ${active ? 'bg-blue-600/20 text-blue-400' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`}>
                <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" /><span>{item.label}</span></button>)})}
          </nav>

          <div className="p-2 sm:p-3 border-t border-slate-800 space-y-2">
            <div className="flex gap-1 justify-center flex-wrap">{locales.map(l => (
              <button key={l.code} onClick={() => setLocale(l.code)} className={`px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] transition ${locale === l.code ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}>{l.code.toUpperCase()}</button>))}</div>
            <button onClick={() => { auth.logout(); setPage('dashboard') }} className="w-full flex items-center justify-center gap-2 px-2.5 py-1.5 rounded-lg text-xs sm:text-sm text-slate-500 hover:bg-red-500/10 hover:text-red-400 transition"><LogOut className="w-3.5 h-3.5" />{t(locale, 'logout')}</button></div>
        </aside>

        {/* Main */}
        <main className="flex-1 min-w-0">
          <header className="lg:hidden sticky top-0 z-30 bg-slate-900/80 backdrop-blur border-b border-slate-800 px-3 py-2 flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="text-slate-400"><Menu className="w-5 h-5" /></button>
            <span className="font-semibold text-sm">{t(locale, 'appName')}</span></header>
          <div className="p-3 sm:p-4 lg:p-6 max-w-7xl mx-auto">{renderPage()}</div>
        </main>

        {/* DIALOG */}
        <Dialog open={dlgOpen} onOpenChange={setDlgOpen}>
          <DialogContent className="bg-slate-900 border-slate-700 text-slate-100 max-w-lg w-[95vw]">
            <DialogHeader><DialogTitle className="text-sm sm:text-base">{dlgEdit ? `Edit ${dlgType}` : `New ${dlgType}`}</DialogTitle></DialogHeader>
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
              {dlgType === 'enterprise' && <><div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Code</Label><Input value={dlgData.code||''} onChange={e=>setDlgData({...dlgData,code:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Email</Label><Input value={dlgData.contactEmail||''} onChange={e=>setDlgData({...dlgData,contactEmail:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Phone</Label><Input value={dlgData.contactPhone||''} onChange={e=>setDlgData({...dlgData,contactPhone:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Address</Label><Input value={dlgData.address||''} onChange={e=>setDlgData({...dlgData,address:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'branch' && <>{role==='super_admin'&&<div><Label className="text-xs">Enterprise</Label><Select value={String(dlgData.enterpriseId||'')} onValueChange={v=>setDlgData({...dlgData,enterpriseId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{enterprises.map(e=><SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>)}</SelectContent></Select></div>}<div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Code</Label><Input value={dlgData.code||''} onChange={e=>setDlgData({...dlgData,code:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Location</Label><Input value={dlgData.location||''} onChange={e=>setDlgData({...dlgData,location:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'warehouse' && <>{role==='super_admin'&&<div><Label className="text-xs">Enterprise</Label><Select value={String(dlgData.enterpriseId||'')} onValueChange={v=>setDlgData({...dlgData,enterpriseId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{enterprises.map(e=><SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>)}</SelectContent></Select></div>}<div><Label className="text-xs">Branch</Label><Select value={String(dlgData.branchId||'')} onValueChange={v=>setDlgData({...dlgData,branchId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{branches.filter(b=>!dlgData.enterpriseId||b.enterpriseId===dlgData.enterpriseId).map(b=><SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}</SelectContent></Select></div><div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Code</Label><Input value={dlgData.code||''} onChange={e=>setDlgData({...dlgData,code:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Capacity</Label><Input type="number" value={dlgData.capacity||''} onChange={e=>setDlgData({...dlgData,capacity:parseInt(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'user' && <>{role==='super_admin'&&<div><Label className="text-xs">Enterprise</Label><Select value={String(dlgData.enterpriseId||'')} onValueChange={v=>setDlgData({...dlgData,enterpriseId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{enterprises.map(e=><SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>)}</SelectContent></Select></div>}<div><Label className="text-xs">Branch</Label><Select value={String(dlgData.branchId||'')} onValueChange={v=>setDlgData({...dlgData,branchId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue placeholder="None" /></SelectTrigger><SelectContent><SelectItem value="0">None</SelectItem>{branches.filter(b=>!dlgData.enterpriseId||b.enterpriseId===dlgData.enterpriseId).map(b=><SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}</SelectContent></Select></div><div><Label className="text-xs">Role</Label><Select value={dlgData.role||''} onValueChange={v=>setDlgData({...dlgData,role:v})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{(MANAGEABLE_ROLES[role!]||[]).map(r=><SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}</SelectContent></Select></div><div><Label className="text-xs">Full Name</Label><Input value={dlgData.fullName||''} onChange={e=>setDlgData({...dlgData,fullName:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Username</Label><Input value={dlgData.username||''} onChange={e=>setDlgData({...dlgData,username:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xsDhPassword</Label><Input type="password" value={dlgData.passwordHash||''} onChange={e=>setDlgData({...dlgData,passwordHash:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" placeholder="admin123" /></div></>}
              {dlgType === 'product' && <><div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">SKU</Label><Input value={dlgData.sku||''} onChange={e=>setDlgData({...dlgData,sku:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Unit</Label><Select value={dlgData.unit||'pcs'} onValueChange={v=>setDlgData({...dlgData,unit:v})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent className="max-h-60">{SORTED_MEASUREMENTS.map(m=><SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent></Select></div><div className="grid grid-cols-2 gap-2"><div><Label className="text-xs">Price</Label><Input type="number" step="0.01" value={dlgData.price||''} onChange={e=>setDlgData({...dlgData,price:parseFloat(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Cost</Label><Input type="number" step="0.01" value={dlgData.cost||''} onChange={e=>setDlgData({...dlgData,cost:parseFloat(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div></div><div><Label className="text-xs">Reorder Level</Label><Input type="number" value={dlgData.reorderLevel||0} onChange={e=>setDlgData({...dlgData,reorderLevel:parseInt(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'stock' && <><div><Label className="text-xs">Product</Label><Input value={products.find(p=>p.id===dlgData.productId)?.name||''} disabled className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Current Qty</Label><Input value={dlgData.quantity||0} disabled className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Adjustment (+/-)</Label><Input type="number" value={dlgData.delta||0} onChange={e=>setDlgData({...dlgData,delta:parseInt(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'order' && <><div><Label className="text-xs">Type</Label><Select value={dlgData.type||'purchase'} onValueChange={v=>setDlgData({...dlgData,type:v})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="purchase">Purchase</SelectItem><SelectItem value="sales">Sales</SelectItem></SelectContent></Select></div><div><Label className="text-xs">Warehouse</Label><Select value={String(dlgData.warehouseId||'')} onValueChange={v=>setDlgData({...dlgData,warehouseId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{warehouses.map(w=><SelectItem key={w.id} value={String(w.id)}>{w.name}</SelectItem>)}</SelectContent></Select></div><div><Label className="text-xs">Notes</Label><Textarea value={dlgData.notes||''} onChange={e=>setDlgData({...dlgData,notes:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'batch' && <><div><Label className="text-xs">Batch Code</Label><Input value={dlgData.batchCode||''} onChange={e=>setDlgData({...dlgData,batchCode:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Warehouse</Label><Select value={String(dlgData.warehouseId||'')} onValueChange={v=>setDlgData({...dlgData,warehouseId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{warehouses.map(w=><SelectItem key={w.id} value={String(w.id)}>{w.name}</SelectItem>)}</SelectContent></Select></div><div><Label className="text-xs">Person Name</Label><Input value={dlgData.personName||''} onChange={e=>setDlgData({...dlgData,personName:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Person Phone</Label><Input value={dlgData.personPhone||''} onChange={e=>setDlgData({...dlgData,personPhone:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Notes</Label><Textarea value={dlgData.notes||''} onChange={e=>setDlgData({...dlgData,notes:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'batchEntry' && <><div><Label className="text-xs">Product</Label><Select value={String(dlgData.productId||'')} onValueChange={v=>setDlgData({...dlgData,productId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{products.map(p=><SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent></Select></div><div className="grid grid-cols-2 gap-2"><div><Label className="text-xs">Quantity</Label><Input type="number" value={dlgData.quantity||''} onChange={e=>setDlgData({...dlgData,quantity:parseInt(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Unit</Label><Select value={dlgData.unit||'pcs'} onValueChange={v=>setDlgData({...dlgData,unit:v})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent className="max-h-60">{SORTED_MEASUREMENTS.map(m=><SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent></Select></div></div><div><Label className="text-xs">Cost Per Unit</Label><Input type="number" step="0.01" value={dlgData.costPerUnit||''} onChange={e=>setDlgData({...dlgData,costPerUnit:parseFloat(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Notes</Label><Input value={dlgData.notes||''} onChange={e=>setDlgData({...dlgData,notes:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'stockOut' && <><div><Label className="text-xs">Person Name</Label><Input value={dlgData.personName||''} onChange={e=>setDlgData({...dlgData,personName:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Phone</Label><Input value={dlgData.personPhone||''} onChange={e=>setDlgData({...dlgData,personPhone:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Email</Label><Input value={dlgData.personEmail||''} onChange={e=>setDlgData({...dlgData,personEmail:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Address</Label><Input value={dlgData.personAddress||''} onChange={e=>setDlgData({...dlgData,personAddress:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Tax Rate (%)</Label><Input type="number" step="0.01" value={dlgData.taxRate!=null?(dlgData.taxRate*100):''} onChange={e=>setDlgData({...dlgData,taxRate:parseFloat(e.target.value)/100||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Notes</Label><Textarea value={dlgData.notes||''} onChange={e=>setDlgData({...dlgData,notes:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'stockOutItem' && <><div><Label className="text-xs">Product</Label><Select value={String(dlgData.productId||'')} onValueChange={v=>setDlgData({...dlgData,productId:parseInt(v)})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent>{products.map(p=><SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent></Select></div><div className="grid grid-cols-2 gap-2"><div><Label className="text-xs">Quantity</Label><Input type="number" value={dlgData.quantity||''} onChange={e=>setDlgData({...dlgData,quantity:parseInt(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Unit</Label><Select value={dlgData.unit||'pcs'} onValueChange={v=>setDlgData({...dlgData,unit:v})}><SelectTrigger className="bg-slate-800 border-slate-700 text-sm"><SelectValue /></SelectTrigger><SelectContent className="max-h-60">{SORTED_MEASUREMENTS.map(m=><SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent></Select></div></div><div><Label className="text-xs">Unit Price</Label><Input type="number" step="0.01" value={dlgData.unitPrice||''} onChange={e=>setDlgData({...dlgData,unitPrice:parseFloat(e.target.value)||0})} className="bg-slate-800 border-slate-700 text-sm" /></div><div className="flex items-center gap-3"><Label className="text-xs">Returnable?</Label><Switch checked={dlgData.isReturnable||false} onCheckedChange={v=>setDlgData({...dlgData,isReturnable:v})} /></div>{dlgData.isReturnable&&<div><Label className="text-xs">Return Deadline</Label><Input type="date" value={dlgData.returnDeadline||''} onChange={e=>setDlgData({...dlgData,returnDeadline:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div>}<div><Label className="text-xs">Notes</Label><Input value={dlgData.notes||''} onChange={e=>setDlgData({...dlgData,notes:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'supplier' && <><div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Contact</Label><Input value={dlgData.contactPerson||''} onChange={e=>setDlgData({...dlgData,contactPerson:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Email</Label><Input value={dlgData.email||''} onChange={e=>setDlgData({...dlgData,email:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Phone</Label><Input value={dlgData.phone||''} onChange={e=>setDlgData({...dlgData,phone:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
              {dlgType === 'category' && <><div><Label className="text-xs">Name</Label><Input value={dlgData.name||''} onChange={e=>setDlgData({...dlgData,name:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div><div><Label className="text-xs">Description</Label><Input value={dlgData.description||''} onChange={e=>setDlgData({...dlgData,description:e.target.value})} className="bg-slate-800 border-slate-700 text-sm" /></div></>}
            </div>
            <DialogFooter><Button variant="ghost" onClick={()=>setDlgOpen(false)} className="text-slate-400 text-sm">{t(locale,'cancel')}</Button>
              <Button onClick={() => {
                const sd = {...dlgData}
                if (dlgType==='user') { if(!sd.enterpriseId) sd.enterpriseId=eid; if(!sd.branchId||sd.branchId===0) sd.branchId=auth.branchId; if(!sd.warehouseId||sd.warehouseId===6) sd.warehouseId=null; if(!sd.passwordHash) sd.passwordHash='admin123' }
                if (dlgType==='product') { if(!sd.enterpriseId) sd.enterpriseId=eid; if(!sd.categoryId||sd.categoryId===0) sd.categoryId=null }
                if (dlgType==='branch'&&!sd.enterpriseId) sd.enterpriseId=eid
                if (dlgType==='warehouse'&&!sd.enterpriseId) sd.enterpriseId=eid
                if (dlgType==='batch'&&!sd.enterpriseId) sd.enterpriseId=eid
                if (dlgType==='stockOut'&&!sd.enterpriseId) sd.enterpriseId=eid
                if (dlgType==='stock') crud.create('/stock',{productId:dlgData.productId,warehouseId:dlgData.warehouseId,delta:dlgData.delta})
                else if (dlgEdit) crud.update(`/${dlgType}s/${dlgEdit.id}`,sd)
                else crud.create(`/${dlgType}s`,sd)
                setDlgOpen(false)
              }} className="bg-blue-600 hover:bg-blue-700 text-sm">{dlgEdit?t(locale,'save'):t(locale,'add')}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  )
}
'''

# Fix the known typos from the template
page = page.replace('Card>CardDescription', 'CardDescription')
page = page.replace('Gh1 className', '<div className="flex items-center justify-between"><h1 className')
page = page.replace('text-xsDhPassword', 'text-xs">Password')

with open('/home/z/my-project/src/app/page.tsx', 'w') as f:
    f.write(page)
print(f"Written {len(page)} chars")
