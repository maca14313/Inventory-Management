#!/usr/bin/env python3
"""
Deployment Guide: Next.js Todo App on cPanel
Generates a professional PDF deployment guide.
"""

import sys, os

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm, inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

# Font Registration
FONT_DIR = '/usr/share/fonts'
pdfmetrics.registerFont(TTFont('NotoSerifSC', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf'))
pdfmetrics.registerFont(TTFont('NotoSerifSC-Bold', f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf'))
registerFontFamily('NotoSerifSC', normal='NotoSerifSC', bold='NotoSerifSC-Bold')

# Colors
C_PRIMARY    = HexColor('#0f766e')
C_ACCENT     = HexColor('#059669')
C_BG_LIGHT   = HexColor('#f0fdf4')
C_BG_SECTION = HexColor('#ecfdf5')
C_TEXT       = HexColor('#1e293b')
C_TEXT_LIGHT = HexColor('#64748b')
C_BORDER     = HexColor('#d1d5db')
C_CODE_BG    = HexColor('#f8fafc')
C_CODE_BORDER= HexColor('#e2e8f0')

# Page Setup
PAGE_W, PAGE_H = A4
LEFT_M = 2.2*cm
RIGHT_M = 2.2*cm
TOP_M = 2.5*cm
BOT_M = 2.5*cm

OUTPUT = '/home/z/my-project/download/todo-app-deployment-guide.pdf'

# Styles
styles = getSampleStyleSheet()

s_title = ParagraphStyle('DocTitle', fontName='NotoSerifSC-Bold', fontSize=28, leading=34, textColor=C_PRIMARY, alignment=TA_LEFT, spaceAfter=6*mm)
s_subtitle = ParagraphStyle('DocSubtitle', fontName='NotoSerifSC', fontSize=14, leading=20, textColor=C_TEXT_LIGHT, alignment=TA_LEFT, spaceAfter=12*mm)
s_h1 = ParagraphStyle('H1', fontName='NotoSerifSC-Bold', fontSize=18, leading=24, textColor=C_PRIMARY, spaceBefore=14*mm, spaceAfter=6*mm)
s_h2 = ParagraphStyle('H2', fontName='NotoSerifSC-Bold', fontSize=13, leading=18, textColor=C_ACCENT, spaceBefore=8*mm, spaceAfter=4*mm)
s_body = ParagraphStyle('Body', fontName='NotoSerifSC', fontSize=10, leading=16, textColor=C_TEXT, alignment=TA_JUSTIFY, spaceAfter=4*mm)
s_bullet = ParagraphStyle('Bullet', fontName='NotoSerifSC', fontSize=10, leading=15, textColor=C_TEXT, leftIndent=14, bulletIndent=4, spaceAfter=2*mm)
s_code = ParagraphStyle('Code', fontName='NotoSerifSC', fontSize=9, leading=13, textColor=HexColor('#334155'), backColor=C_CODE_BG, borderColor=C_CODE_BORDER, borderWidth=0.5, borderPadding=6, leftIndent=8, spaceAfter=4*mm, spaceBefore=2*mm)
s_table_header = ParagraphStyle('TableHeader', fontName='NotoSerifSC-Bold', fontSize=9, leading=12, textColor=white, alignment=TA_LEFT)
s4 = ParagraphStyle('TableCell', fontName='NotoSerifSC', fontSize=9, leading=12, textColor=C_TEXT, alignment=TA_LEFT)
s_note = ParagraphStyle('Note', fontName='NotoSerifSC', fontSize=9, leading=14, textColor=HexColor('#92400e'), backColor=HexColor('#fef3c7'), borderColor=HexColor('#fbbf24'), borderWidth=1, borderPadding=8, leftIndent=8, spaceAfter=5*mm, spaceBefore=3*mm)
s_tip = ParagraphStyle('Tip', fontName='NotoSerifSC', fontSize=9, leading=14, textColor=HexColor('#065f46'), backColor=HexColor('#ecfdf5'), borderColor=HexColor('#34d399'), borderWidth=1, borderPadding=8, leftIndent=8, spaceAfter=5*mm, spaceBefore=3*mm)

def h1(text): return Paragraph(text, s_h1)
def h2(text): return Paragraph(text, s_h2)
def p(text): return Paragraph(text, s_body)
def bullet(text): return Paragraph(f'<bullet>&bull;</bullet> {text}', s_bullet)
def code(text): return Paragraph(text.replace('\n', '<br/>').replace(' ', '&nbsp;'), s_code)
def note(text): return Paragraph(text, s_note)
def tip(text): return Paragraph(text, s_tip)
def hr(): return HRFlowable(width='100%', thickness=0.5, color=C_BORDER, spaceBefore=4*mm, spaceAfter=4*mm)

def make_table(headers, rows, col_widths=None):
    avail = PAGE_W - LEFT_M - RIGHT_M
    if col_widths is None:
        col_widths = [avail / len(headers)] * len(headers)
    else:
        total = sum(col_widths)
        col_widths = [w / total * avail for w in col_widths]
    data = [[Paragraph(h, s_table_header) for h in headers]]
    for row in rows:
        data.append([Paragraph(str(c), s4) for c in row])
    t = Table(data, colWidths=col_widths)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_PRIMARY),
        ('TEXTCOLOR', (0,0), (-1,0), white),
        ('BACKGROUND', (0,1), (-1,-1), white),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, C_CODE_BG]),
        ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    return t

def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(C_BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(LEFT_M, BOT_M - 8*mm, PAGE_W - RIGHT_M, BOT_M - 8*mm)
    canvas.setFont('NotoSerifSC', 8)
    canvas.setFillColor(C_TEXT_LIGHT)
    canvas.drawCentredString(PAGE_W / 2, BOT_M - 14*mm, f'Page {doc.page}')
    canvas.setFont('NotoSerifSC', 7)
    canvas.drawString(LEFT_M, PAGE_H - TOP_M + 10*mm, 'Todo App Deployment Guide')
    canvas.drawRightString(PAGE_W - RIGHT_M, PAGE_H - TOP_M + 10*mm, 'Next.js + MySQL on cPanel')
    canvas.restoreState()

doc = SimpleDocTemplate(OUTPUT, pagesize=A4, leftMargin=LEFT_M, rightMargin=RIGHT_M, topMargin=TOP_M, bottomMargin=BOT_M, title='Todo App Deployment Guide', author='Z.ai', subject='Deployment guide for Next.js Todo App on cPanel')

story = []

# Cover
story.append(Spacer(1, 25*mm))
story.append(Paragraph('Todo App', s_title))
story.append(Paragraph('Deployment Guide', ParagraphStyle('CT2', fontName='NotoSerifSC-Bold', fontSize=22, leading=28, textColor=C_ACCENT, spaceAfter=8*mm)))
story.append(Paragraph('Next.js 16 + MySQL on cPanel<br/>CloudLinux + LiteSpeed + Phusion Passenger', s_subtitle))
story.append(hr())
story.append(Spacer(1, 5*mm))

info_data = [
    [Paragraph('<b>Application</b>', s4), Paragraph('Next.js 16 Todo List App', s4)],
    [Paragraph('<b>Target URL</b>', s4), Paragraph('homepage-test-1.drjeilan.net/todo', s4)],
    [Paragraph('<b>Server Stack</b>', s4), Paragraph('cPanel + CloudLinux + LiteSpeed + Passenger', s4)],
    [Paragraph('<b>Node.js</b>', s4), Paragraph('v20.20.2 (minimum v18.6 required)', s4)],
    [Paragraph('<b>Database</b>', s4), Paragraph('MySQL (drjeilkt_test_todo)', s4)],
    [Paragraph('<b>Deployment</b>', s4), Paragraph('File Manager upload + cPanel NodeJS Selector', s4)],
]
info_table = Table(info_data, colWidths=[4*cm, 12*cm])
info_table.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (0,-1), C_BG_LIGHT),
    ('GRID', (0,0), (-1,-1), 0.5, C_BORDER),
    ('LEFTPADDING', (0,0), (-1,-1), 10), ('RIGHTPADDING', (0,0), (-1,-1), 10),
    ('TOPPADDING', (0,0), (-1,-1), 6), ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
]))
story.append(info_table)
story.append(PageBreak())

# Section 1: Architecture
story.append(h1('1. Architecture Overview'))
story.append(p('This guide documents the complete deployment process for a Next.js 16 Todo List application on a cPanel-managed server running CloudLinux, LiteSpeed, and Phusion Passenger. The deployment was developed and debugged through an iterative process, solving multiple compatibility issues between Next.js 16, CloudLinux NodeJS Selector, and LiteSpeed Passenger. Understanding the architecture is essential because many standard Next.js deployment patterns do not work in this environment and require specific workarounds.'))

story.append(h2('1.1 Server Stack'))
story.append(p('The target server uses a specialized hosting stack that differs significantly from standard VPS or cloud deployments. Each component introduces constraints that affect how the application must be built, packaged, and configured. CloudLinux isolates each user account with its own resource limits and virtual environment, LiteSpeed replaces Apache/Nginx as the web server, and Phusion Passenger manages Node.js application processes. This combination is common in shared hosting environments but requires careful adaptation of standard deployment workflows.'))

story.append(make_table(['Component', 'Role', 'Key Constraint'], [
    ['cPanel', 'Server management UI', 'No SSH access; use File Manager for uploads'],
    ['CloudLinux', 'OS-level isolation', 'node_modules is a symlink (virtual env); no real folder allowed'],
    ['LiteSpeed', 'Web server', 'Replaces Apache; uses Passenger for Node.js apps'],
    ['Phusion Passenger', 'App process manager', 'Intercepts .listen(); reads server.js as entry point'],
    ['NodeJS Selector', 'cPanel Node manager', 'Manages npm install in virtual environment'],
    ['MySQL', 'Database', 'Tables auto-created on first API request'],
], [2, 2.5, 4.5]))

story.append(h2('1.2 Request Flow'))
story.append(p('When a user visits the application URL, the request follows a specific path through the server stack. LiteSpeed receives the HTTP request and routes it through Passenger based on the configured Application URL. Passenger manages the Node.js process lifecycle, starting the application if needed and forwarding requests to the running server.js instance. The Node.js application processes the request through Next.js, which handles both page rendering and API route dispatching. Static assets are served directly by the Node.js process through Next.js built-in static file handling.'))
story.append(code('Browser --> LiteSpeed --> Passenger --> server.js --> Next.js --> Page/API Response'))

# Section 2: Issues Solved
story.append(h1('2. Issues Solved During Development'))
story.append(p('Deploying a Next.js application on this hosting stack required solving six distinct compatibility issues, each of which caused the application to fail in a different way. This section documents each issue, its root cause, and the solution that was implemented. These solutions are already incorporated into the deployment package, but understanding them is important for future troubleshooting or if you need to deploy a different Next.js application on the same server.'))

issues = [
    ('2.1 Node.js Version Mismatch (SyntaxError: Unexpected token ?)',
     'The CloudLinux NodeJS Selector was configured to use Node.js 10, but Next.js 16 requires Node.js 18.6 or higher. The nullish coalescing operator (??) and optional chaining (?.) used in Next.js internal code are ES2020 features that Node.js 10 cannot parse. This resulted in a SyntaxError at the very first require() call, preventing the application from starting at all. The Node version was visible in the virtual environment path: /home/drjeilkt/nodevenv/todo-app/10/.',
     'SOLUTION: Recreate the Node.js app in cPanel Setup Node.js App with Node.js version 20 (or minimum 18). The number in the nodevenv path must be 20, not 10.'),

    ('2.2 basePath Ignored by Turbopack (.ts config)',
     'The application is deployed at a subpath (/todo) rather than the domain root. Next.js requires basePath: "/todo" in its configuration to handle this correctly. However, Turbopack (Next.js 16 default compiler) ignored the basePath setting when it was defined in next.config.ts (TypeScript format). The routes-manifest.json showed basePath as an empty string despite the config being correct. This caused all routes and static asset paths to be generated without the /todo prefix, resulting in 404 errors.',
     'SOLUTION: Switch from next.config.ts to next.config.js (CommonJS format). Turbopack correctly reads basePath from .js config but not from .ts config. Verify by checking .next/routes-manifest.json after build.'),

    ('2.3 Client-Side fetch() Paths Ignored basePath',
     'Even with basePath correctly configured on the server side, client-side fetch() calls used absolute paths like fetch("/api/todos"). These resolved to the domain root (domain.com/api/todos) instead of the subpath (domain.com/todo/api/todos). Unlike Next.js Link and useRouter components, raw fetch() calls do not automatically prepend basePath. This caused all API requests to return 404.',
     'SOLUTION: Define NEXT_PUBLIC_BASE_PATH env var in next.config.js (set to "/todo") and prefix all fetch URLs: fetch(`${BASE}/api/todos`) where BASE = process.env.NEXT_PUBLIC_BASE_PATH || "".'),

    ('2.4 Express Module Not Found (Cannot find module "express")',
     'The server.js entry point initially used Express (require("express")) to set up the HTTP server. However, Express was not included in the minimal deployment package.json. When Passenger loaded server.js, it immediately failed because the express module was not installed in the CloudLinux virtual environment.',
     'SOLUTION: Rewrite server.js to use Node.js built-in http.createServer instead of Express. No external HTTP framework is needed because Next.js handles all routing via its request handler.'),

    ('2.5 better-sqlite3 Native Module Not Available',
     'The database driver (db.ts) included a SQLite fallback for local development using better-sqlite3. Although this code path was never executed in production (where MySQL is configured), the bundler statically analyzed the require("better-sqlite3") call and included it in the compiled output. At runtime on the server, the module could not be found because better-sqlite3 was not in the deployment dependencies.',
     'SOLUTION: Remove all SQLite/better-sqlite3 code from db.ts. Use MySQL exclusively with support for both DATABASE_URL and separate DB_HOST/DB_USER/DB_PASSWORD/DB_NAME environment variable patterns.'),

    ('2.6 CloudLinux Virtual Environment and node_modules',
     'CloudLinux NodeJS Selector manages dependencies through a virtual environment where node_modules is a symlink pointing to a separate directory. The application root must NOT contain a real node_modules directory. If a real node_modules folder is uploaded, CloudLinux rejects it with an error message. The "Run NPM Install" button in cPanel creates the symlink and installs packages into the virtual environment directory.',
     'SOLUTION: Exclude node_modules from the deployment tar.gz. Use cPanel Run NPM Install to populate the virtual environment. Never upload a node_modules folder via File Manager.'),
]

for title, desc, sol in issues:
    story.append(h2(title))
    story.append(p(desc))
    story.append(note(sol))

# Section 3: Package Contents
story.append(PageBreak())
story.append(h1('3. Deployment Package Contents'))
story.append(p('The deployment package (todo-app.tar.gz, approximately 2.3 MB) contains only the files needed to run the application on the server. It does not include node_modules (managed by CloudLinux), source TypeScript files (compiled into .next), or development dependencies. Understanding the purpose of each file helps with troubleshooting and future updates.'))

story.append(make_table(['File/Directory', 'Purpose'], [
    ['server.js', 'Entry point for Passenger. Uses http.createServer + Next.js request handler.'],
    ['package.json', 'Minimal dependency list for npm install in CloudLinux virtual env.'],
    ['next.config.js', 'Next.js config: basePath=/todo, NEXT_PUBLIC_BASE_PATH env var.'],
    ['.next/', 'Compiled production build output (pages, API routes, static assets).'],
    ['public/', 'Static public assets (favicon, etc.).'],
], [3, 6]))

story.append(h2('3.1 package.json Dependencies'))
story.append(p('The deployment package.json includes only the runtime dependencies needed by the application. Development dependencies (TypeScript, ESLint, Tailwind CSS compiler) are excluded because they are not needed at runtime. The build step has already compiled and bundled everything into the .next directory.'))

story.append(make_table(['Package', 'Version', 'Purpose'], [
    ['next', '16.1.3', 'Next.js framework (routing, SSR, API routes)'],
    ['react', '19.2.3', 'React runtime'],
    ['react-dom', '19.2.3', 'React DOM renderer'],
    ['mysql2', '3.23.2', 'MySQL driver with promise support'],
    ['@radix-ui/react-checkbox', '1.3.3', 'Checkbox UI component primitive'],
    ['@radix-ui/react-slot', '1.2.4', 'Slot component for composable patterns'],
    ['@radix-ui/react-toast', '1.2.14', 'Toast notification UI primitive'],
    ['lucide-react', '0.525.0', 'Icon library (Plus, Trash2, Pencil, etc.)'],
    ['class-variance-authority', '0.7.1', 'CSS variant utility for components'],
    ['clsx', '2.1.1', 'Conditional CSS class joiner'],
    ['tailwind-merge', '3.4.0', 'Tailwind class conflict resolver'],
    ['tailwindcss-animate', '1.0.7', 'Tailwind animation utilities'],
], [3.5, 1.5, 4]))

# Section 4: Deployment Steps
story.append(h1('4. Step-by-Step Deployment'))
story.append(p('This section provides the complete deployment procedure from start to finish. Follow these steps in order. Each step builds on the previous one, and skipping steps will result in errors. The entire process typically takes 10-15 minutes, with most time spent on file upload and npm install.'))

deploy_steps = [
    ('Step 1: Download the Deployment Package', 'Download the todo-app.tar.gz file from the build output. This file contains the complete production build with all compiled pages, API routes, and static assets. The file is approximately 2.3 MB. Save it to your local machine for upload to the server.'),
    ('Step 2: Clean the Application Directory', 'Open cPanel File Manager and navigate to the todo-app directory. Delete ALL existing files and folders inside this directory. This is critical because old build artifacts (especially the .next folder and old server.js) can conflict with the new deployment. Ensure the todo-app directory is completely empty before proceeding.'),
    ('Step 3: Upload and Extract', 'Upload the todo-app.tar.gz file into the todo-app/ directory using cPanel File Manager. Then right-click the uploaded file and select Extract to decompress it. After extraction, verify that server.js, package.json, next.config.js, .next/, and public/ exist directly inside todo-app/. Delete the tar.gz file after extraction. Do NOT create or upload a node_modules folder.'),
    ('Step 4: Configure the Node.js Application', 'Navigate to cPanel > Setup Node.js App. If an existing todo-app entry exists, delete it first by clicking the trash icon. Then create a new application with: Node.js version = 20 (NOT 10), Application root = todo-app, Application URL = homepage-test-1.drjeilan.net/todo, Application startup file = server.js.'),
    ('Step 5: Run NPM Install', 'After creating the application, click the Run NPM Install button in the NodeJS Selector interface. This installs all dependencies from package.json into the CloudLinux virtual environment. The process may take 1-2 minutes. Wait for it to complete before proceeding. The node_modules symlink in the application root will automatically point to the virtual environment.'),
    ('Step 6: Set Environment Variables', 'In the same NodeJS Selector interface, add the following environment variables: DB_HOST = localhost, DB_USER = drjeilkt_test_todo, DB_PASSWORD = 3FTO(ppoZwXdNoJ9, DB_NAME = drjeilkt_test_todo. These are required for the MySQL database connection. The application uses separate environment variables rather than a DATABASE_URL string because special characters in the password do not cause URL encoding issues with this approach.'),
    ('Step 7: Start the Application', 'Click the Restart button in the NodeJS Selector interface to start the application. The first request may take a few seconds as Next.js initializes. After starting, verify by visiting /todo/api/health first to check MySQL connectivity, then visit /todo/ to see the application.'),
]

for title, desc in deploy_steps:
    story.append(h2(title))
    story.append(p(desc))

story.append(note('IMPORTANT: For Step 2, delete the CONTENTS of todo-app/, not the todo-app directory itself. The directory must exist for the NodeJS Selector to find the application.'))

story.append(tip('Test order: First visit /todo/api/health to verify MySQL connectivity. Then visit /todo/ to see the application. The Todo table is created automatically on the first API request, so no manual database setup is needed.'))

# Section 5: Troubleshooting
story.append(PageBreak())
story.append(h1('5. Verification and Troubleshooting'))

story.append(h2('5.1 Health Check Endpoint'))
story.append(p('The application includes a built-in diagnostic endpoint at /todo/api/health that tests the MySQL connection and reports environment variable status. Visit this URL in your browser to see a JSON response with connection details. The response includes the status of each environment variable (set or not set), the MySQL connection result, and whether the Todo table exists in the database.'))
story.append(code('URL: https://homepage-test-1.drjeilan.net/todo/api/health<br/><br/>Expected response:<br/>{<br/>&nbsp;&nbsp;"env": { "DB_HOST": "localhost", "DB_USER": "drjeilkt_test_todo", "DB_PASSWORD": "***set***", "DB_NAME": "drjeilkt_test_todo" },<br/>&nbsp;&nbsp;"db": { "status": "CONNECTED", "todoTableExists": true }<br/>}'))

story.append(h2('5.2 Common Error Reference'))
story.append(p('The following table maps common error messages to their root causes and solutions. If you encounter an error not listed here, check the Node.js application logs in cPanel for detailed stack traces.'))

story.append(make_table(['Error', 'Cause', 'Solution'], [
    ['503 Service Unavailable', 'App failed to start or Passenger cannot reach it', 'Check Node.js version is 20; verify server.js has no syntax errors; restart'],
    ['SyntaxError: Unexpected token ?', 'Node.js 10 cannot parse ES2020 syntax', 'Recreate app with Node.js 20 in cPanel Setup Node.js App'],
    ['Cannot find module "express"', 'server.js references Express which is not installed', 'server.js should use http.createServer, not Express'],
    ['Cannot find module "next"', 'npm install not run or virtual env broken', 'Click Run NPM Install; verify node_modules symlink exists'],
    ['404 page not found', 'basePath not configured or wrong config format', 'Use next.config.js (not .ts) with basePath: "/todo"'],
    ['Cannot find module "better-sqlite3"', 'SQLite dev fallback bundled in build', 'Remove all better-sqlite3 code from db.ts; use MySQL only'],
    ['Failed to load todos (UI)', 'fetch() URLs missing basePath prefix', 'Use NEXT_PUBLIC_BASE_PATH env var to prefix API URLs'],
    ['MODULE_NOT_FOUND (CloudLinux)', 'Real node_modules folder in app root', 'Delete node_modules folder; use Run NPM Install instead'],
], [2.5, 2.5, 4]))

story.append(h2('5.3 Debugging Steps'))
story.append(p('When the application is not working, follow these debugging steps in order. Each step checks a different layer of the stack, starting from the server environment and working up to the application logic.'))

debug_items = [
    'Check Node.js version: In cPanel Setup Node.js App, confirm the version is 20. The virtual env path should contain /20/ not /10/.',
    'Check npm install: Click Run NPM Install and wait for completion. Check that the node_modules symlink exists in the app root.',
    'Check env vars: Verify all four DB_ variables are set in the NodeJS Selector interface. Values are case-sensitive.',
    'Check health endpoint: Visit /todo/api/health. If it returns JSON with db.status "CONNECTED", the database works. If "ERROR", read the message field.',
    'Check server.js: Ensure it uses http.createServer (not Express). The first require should be require("http"), not require("express").',
    'Check basePath: Verify next.config.js exists (not .ts) and contains basePath: "/todo".',
    'Restart the app: Click Restart in NodeJS Selector. Wait 5 seconds, then test again.',
]
for i, step in enumerate(debug_items, 1):
    story.append(Paragraph(f'<bullet>{i}.</bullet> {step}', s_bullet))

# Section 6: Responsibilities
story.append(h1('6. Your Responsibilities vs Build Responsibilities'))
story.append(p('Deployment is a shared responsibility between the build process (which produces the deployment package) and the server administrator (who deploys it). Understanding this separation is important for knowing what you can change on the server versus what requires a new build.'))

story.append(h2('6.1 What the Build Process Handles'))
story.append(p('The build process runs on the development machine and produces the deployment package. Any changes to these items require rebuilding the application and uploading a new package. These are typically code-level changes that cannot be fixed by configuration alone.'))
build_items = [
    '<b>Next.js compilation:</b> All TypeScript/React source files are compiled into optimized JavaScript in the .next directory.',
    '<b>basePath configuration:</b> The /todo subpath prefix is baked into the build output. Changing the URL path requires a rebuild.',
    '<b>Client-side API URLs:</b> The NEXT_PUBLIC_BASE_PATH value is inlined into the compiled JavaScript at build time.',
    '<b>Dependency list:</b> The package.json specifies exact versions of runtime dependencies. Adding or upgrading requires updating and rebuilding.',
    '<b>SQLite code removal:</b> The build output must not contain references to better-sqlite3.',
    '<b>server.js entry point:</b> Must use http.createServer (not Express) and reference only modules in the deployment package.json.',
]
for item in build_items:
    story.append(bullet(item))

story.append(h2('6.2 What You Handle on the Server'))
story.append(p('These tasks are performed through the cPanel interface and do not require rebuilding the application. They are configuration and operational tasks that adapt the same build to different environments or resolve runtime issues.'))
server_items = [
    '<b>Node.js version selection:</b> Choose version 20 (or 18+) in cPanel Setup Node.js App.',
    '<b>npm install:</b> Click Run NPM Install after uploading a new package to populate the CloudLinux virtual environment.',
    '<b>Environment variables:</b> Set DB_HOST, DB_USER, DB_PASSWORD, DB_NAME through the NodeJS Selector interface.',
    '<b>Application restart:</b> Click Restart after changing env vars or updating files.',
    '<b>File uploads:</b> Use cPanel File Manager to upload and extract the deployment tar.gz.',
    '<b>Database creation:</b> Create the MySQL database and user through cPanel MySQL Databases. The app auto-creates the Todo table.',
]
for item in server_items:
    story.append(bullet(item))

# Section 7: Updating
story.append(h1('7. Updating the Application'))
story.append(p('When code changes are needed, the update process follows the same pattern as the initial deployment. The build process produces a new tar.gz, and you deploy it to the server. The key principle is that code changes always require a new build, while configuration changes (env vars, Node version) can be made directly in cPanel without rebuilding.'))

story.append(h2('7.1 Update Workflow'))
update_steps = [
    'Make code changes on the development machine.',
    'Run "npx next build" to compile the new production build.',
    'Create a new deployment tar.gz with updated .next, server.js, package.json, and next.config.js.',
    'In cPanel File Manager, delete the old .next folder and old files in todo-app/.',
    'Upload and extract the new tar.gz into todo-app/.',
    'If package.json changed (new dependencies), click Run NPM Install in NodeJS Selector.',
    'Click Restart in NodeJS Selector to load the new build.',
]
for i, step in enumerate(update_steps, 1):
    story.append(Paragraph(f'<bullet>{i}.</bullet> {step}', s_bullet))

story.append(h2('7.2 When NPM Install is Needed'))
story.append(p('You only need to run NPM Install when the package.json has changed (new or upgraded dependencies). If only source code changed and no new npm packages were added, you can skip NPM Install and just restart the application. However, if you are unsure, running NPM Install is always safe; it simply verifies that all declared dependencies are installed.'))

# Section 8: Config Reference
story.append(PageBreak())
story.append(h1('8. Key Configuration Files Reference'))
story.append(p('This section provides the complete contents of the key configuration files for reference. If any file is accidentally deleted or corrupted on the server, you can recreate it from these listings.'))

story.append(h2('8.1 server.js'))
story.append(code("const { createServer } = require('http')<br/>const next = require('next')<br/><br/>const app = next({ dev: false })<br/>const handle = app.getRequestHandler()<br/>const port = parseInt(process.env.PORT, 10) || 3000<br/><br/>app.prepare().then(() => {<br/>&nbsp;&nbsp;createServer((req, res) => {<br/>&nbsp;&nbsp;&nbsp;&nbsp;handle(req, res)<br/>&nbsp;&nbsp;}).listen(port, () => {<br/>&nbsp;&nbsp;&nbsp;&nbsp;console.log(`[server] Ready on port ${port}`)<br/>&nbsp;&nbsp;})<br/>}).catch((err) => {<br/>&nbsp;&nbsp;console.error('[server] Failed to start:', err)<br/>&nbsp;&nbsp;process.exit(1)<br/>})"))

story.append(h2('8.2 next.config.js'))
story.append(code("/** @type {import('next').NextConfig} */<br/>const nextConfig = {<br/>&nbsp;&nbsp;basePath: '/todo',<br/>&nbsp;&nbsp;env: {<br/>&nbsp;&nbsp;&nbsp;&nbsp;NEXT_PUBLIC_BASE_PATH: '/todo',<br/>&nbsp;&nbsp;},<br/>&nbsp;&nbsp;typescript: { ignoreBuildErrors: true },<br/>&nbsp;&nbsp;reactStrictMode: false,<br/>};<br/>module.exports = nextConfig;"))

story.append(h2('8.3 Environment Variables Summary'))
story.append(make_table(['Variable', 'Value', 'Set Where', 'Required?'], [
    ['DB_HOST', 'localhost', 'cPanel NodeJS Selector', 'Yes'],
    ['DB_USER', 'drjeilkt_test_todo', 'cPanel NodeJS Selector', 'Yes'],
    ['DB_PASSWORD', '3FTO(ppoZwXdNoJ9', 'cPanel NodeJS Selector', 'Yes'],
    ['DB_NAME', 'drjeilkt_test_todo', 'cPanel NodeJS Selector', 'Yes'],
    ['PORT', '(auto by Passenger)', 'Passenger runtime', 'No'],
    ['NODE_ENV', 'production', 'Auto (Passenger)', 'No'],
], [2.5, 3, 2.5, 1.5]))

story.append(tip('The /todo/api/health endpoint is your first diagnostic tool. It shows exactly which env vars are set and whether MySQL connectivity works. Bookmark this URL for quick troubleshooting.'))

# Build
doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
print(f'[OK] PDF generated: {OUTPUT}')
print(f'[OK] Size: {os.path.getsize(OUTPUT) / 1024:.1f} KB')
