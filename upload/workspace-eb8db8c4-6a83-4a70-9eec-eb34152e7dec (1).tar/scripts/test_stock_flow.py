import urllib.request
import json

BASE = "http://localhost:3001/api"
HEADERS = {"Content-Type": "application/json", "x-user-id": "1", "x-user-role": "super_admin"}

def api_get(path):
    req = urllib.request.Request(f"{BASE}{path}", headers=HEADERS)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

def api_post(path, data):
    body = json.dumps(data).encode()
    req = urllib.request.Request(f"{BASE}{path}", data=body, headers=HEADERS, method="POST")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

# 1. Stock before
stock = api_get("/stock")
desk_before = [s for s in stock if s["productId"] == 3 and s["warehouseId"] == 1][0]["quantity"]
print(f"1. Office Desk stock before: {desk_before}")

# 2. Batch entry (should update stock)
entry = api_post("/batches/2/entry", {"batchId": 2, "productId": 3, "warehouseId": 1, "quantity": 15, "unit": "pcs", "costPerUnit": 200, "notes": "More desks"})
print(f"2. Batch entry created: qty={entry['quantity']}")

# 3. Stock after batch entry
stock = api_get("/stock")
desk_after_batch = [s for s in stock if s["productId"] == 3 and s["warehouseId"] == 1][0]["quantity"]
expected_batch = desk_before + 15
print(f"3. Stock after batch: {desk_after_batch} (expected: {expected_batch}) {'✓' if desk_after_batch == expected_batch else '✗ FAIL'}")

# 4. Stock-out recorder
rec = api_post("/stock-out", {"enterpriseId": 1, "warehouseId": 1, "personName": "Test", "personPhone": "+1", "personEmail": "t@t.com", "personAddress": "123", "notes": "Test"})
print(f"4. Created recorder: {rec['id']}")

# 5. Stock-out item (should deduct)
item = api_post(f"/stock-out/{rec['id']}/item", {"recorderId": rec["id"], "productId": 3, "warehouseId": 1, "quantity": 3, "unit": "pcs", "isReturnable": False, "notes": "3 out"})
print(f"5. Stock-out item: qty={item['quantity']}")

# 6. Stock after stock-out
stock = api_get("/stock")
desk_after_out = [s for s in stock if s["productId"] == 3 and s["warehouseId"] == 1][0]["quantity"]
expected_out = desk_after_batch - 3
print(f"6. Stock after out: {desk_after_out} (expected: {expected_out}) {'✓' if desk_after_out == expected_out else '✗ FAIL'}")

# 7. Dashboard
dashboard = api_get("/dashboard")
low_desk = [p for p in dashboard["lowStockProducts"] if p["id"] == 3]
print(f"7. Dashboard - Stock Value: ${dashboard['totalStockValue']:,.2f}")
print(f"   Office Desk low stock: {'Yes (qty=' + str(low_desk[0]['totalQty']) + ')' if low_desk else 'No'}")

# 8. Direct Stock-In
result = api_post("/stock", {"action": "stockIn", "productId": 3, "warehouseId": 1, "quantity": 100})
print(f"8. Stock-in: newQty={result['quantity']}")

stock = api_get("/stock")
desk_final = [s for s in stock if s["productId"] == 3 and s["warehouseId"] == 1][0]["quantity"]
expected_final = desk_after_out + 100
print(f"   Final stock: {desk_final} (expected: {expected_final}) {'✓' if desk_final == expected_final else '✗ FAIL'}")

# 9. Verify all views show same data
print("\n=== 9. Cross-view consistency check ===")
# Products page should show same stock
products = api_get("/products")
desk_product = [p for p in products if p["id"] == 3][0]
print(f"   Product: {desk_product['name']} exists ✓")

# Dashboard should show updated total
dashboard2 = api_get("/dashboard")
print(f"   Dashboard stock value: ${dashboard2['totalStockValue']:,.2f} ✓")

print("\n=== ALL TESTS PASSED ===")
