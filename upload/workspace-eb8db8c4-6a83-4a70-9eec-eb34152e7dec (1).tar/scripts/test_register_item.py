#!/usr/bin/env python3
"""Test the Register Item flow and data consistency."""
import json, urllib.request

BASE = "http://localhost:3000/api"

def api(method, path, data=None):
    headers = {"Content-Type": "application/json", "x-user-id": "1", "x-user-role": "super_admin"}
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(f"{BASE}{path}", data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except Exception as e:
        print(f"  ERROR: {e}")
        return None

# Register a new item
print("=== REGISTER ITEM: Create product + stock in ===")
prod = api("POST", "/products", {
    "enterpriseId": 1, "name": "Test Wireless Mouse", "sku": "TEST-MOUSE-001",
    "description": "Test product", "categoryId": 1, "price": 29.99, "cost": 10,
    "unit": "pcs", "reorderLevel": 20, "isActive": True
})
if not prod:
    print("  ERROR creating product!")
    exit(1)
pid = prod["id"]
print(f"  Created product ID: {pid}, name: {prod['name']}")

stock = api("POST", "/stock", {"action": "stockIn", "productId": pid, "warehouseId": 1, "quantity": 100})
if stock:
    print(f"  Stock in result: qty={stock['quantity']}")
else:
    print("  ERROR with stock in!")

# Verify in stock list
print("\n=== VERIFY IN STOCK LIST ===")
stocks = api("GET", "/stock") or []
for s in stocks:
    if s["productId"] == pid:
        print(f"  Product {pid} WH {s['warehouseId']}: qty={s['quantity']} PASS")

# Verify in products list
print("\n=== VERIFY IN PRODUCTS LIST ===")
prods = api("GET", "/products") or []
for p in prods:
    if p["id"] == pid:
        print(f"  Product: {p['name']} ({p['sku']}) price={p['price']} unit={p['unit']} PASS")

# Verify dashboard reflects new data
print("\n=== VERIFY DASHBOARD ===")
d = api("GET", "/dashboard")
if d:
    print(f"  Product count: {d['productCount']}")
    print(f"  Total stock value: ${d['totalStockValue']:,.2f}")
    print(f"  Low stock products: {len(d['lowStockProducts'])}")

print("\n=== ALL REGISTER ITEM TESTS COMPLETE ===")
