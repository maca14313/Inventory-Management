#!/bin/bash
BASE="http://localhost:3001/api"
H1="Content-Type: application/json"
H2="x-user-id: 1"
H3="x-user-role: super_admin"

echo "=== 1. Stock before batch entry ==="
STOCK_BEFORE=$(curl -s "$BASE/stock" -H "$H1" -H "$H2" -H "$H3" | python3 -c "import sys,json; data=json.load(sys.stdin); desk=[s for s in data if s['productId']==3 and s['warehouseId']==1]; print(desk[0]['quantity'] if desk else '0')")
echo "Office Desk stock: $STOCK_BEFORE"

echo "=== 2. Add batch entry ==="
RESULT=$(curl -s -X POST "$BASE/batches/2/entry" -H "$H1" -H "$H2" -H "$H3" -d '{"batchId":2,"productId":3,"warehouseId":1,"quantity":15,"unit":"pcs","costPerUnit":200,"notes":"More desks"}')
echo "Entry: $RESULT"

echo "=== 3. Stock after batch entry ==="
STOCK_AFTER_BATCH=$(curl -s "$BASE/stock" -H "$H1" -H "$H2" -H "$H3" | python3 -c "import sys,json; data=json.load(sys.stdin); desk=[s for s in data if s['productId']==3 and s['warehouseId']==1]; print(desk[0]['quantity'] if desk else 'NOT FOUND')")
echo "Office Desk stock: $STOCK_AFTER_BATCH (expected: $((STOCK_BEFORE + 15)))"

echo "=== 4. Create stock-out recorder ==="
REC=$(curl -s -X POST "$BASE/stock-out" -H "$H1" -H "$H2" -H "$H3" -d '{"enterpriseId":1,"warehouseId":1,"personName":"Test","personPhone":"+1","personEmail":"t@t.com","personAddress":"123","notes":"Test"}')
REC_ID=$(echo "$REC" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "Recorder ID: $REC_ID"

echo "=== 5. Stock-out item ==="
OUT_RESULT=$(curl -s -X POST "$BASE/stock-out/$REC_ID/item" -H "$H1" -H "$H2" -H "$H3" -d "{\"recorderId\":$REC_ID,\"productId\":3,\"warehouseId\":1,\"quantity\":3,\"unit\":\"pcs\",\"isReturnable\":false,\"notes\":\"3 out\"}")
echo "Out: $OUT_RESULT"

echo "=== 6. Stock after stock-out ==="
STOCK_AFTER_OUT=$(curl -s "$BASE/stock" -H "$H1" -H "$H2" -H "$H3" | python3 -c "import sys,json; data=json.load(sys.stdin); desk=[s for s in data if s['productId']==3 and s['warehouseId']==1]; print(desk[0]['quantity'] if desk else 'NOT FOUND')")
echo "Office Desk stock: $STOCK_AFTER_OUT (expected: $((STOCK_AFTER_BATCH - 3)))"

echo "=== 7. Dashboard ==="
curl -s "$BASE/dashboard" -H "$H1" -H "$H2" -H "$H3" | python3 -c "
import sys,json
d=json.load(sys.stdin)
low=[p for p in d['lowStockProducts'] if p['id']==3]
print('Total Stock Value: ' + str(d['totalStockValue']))
print('Office Desk low stock: ' + ('Yes (qty=' + str(low[0]['totalQty']) + ')' if low else 'No'))"

echo "=== 8. Direct Stock-In ==="
curl -s -X POST "$BASE/stock" -H "$H1" -H "$H2" -H "$H3" -d '{"action":"stockIn","productId":3,"warehouseId":1,"quantity":100}' | python3 -c "import sys,json; d=json.load(sys.stdin); print('New qty: ' + str(d['quantity']))"

STOCK_FINAL=$(curl -s "$BASE/stock" -H "$H1" -H "$H2" -H "$H3" | python3 -c "import sys,json; data=json.load(sys.stdin); desk=[s for s in data if s['productId']==3 and s['warehouseId']==1]; print(desk[0]['quantity'] if desk else 'NOT FOUND')")
echo "Final stock: $STOCK_FINAL (expected: $((STOCK_AFTER_OUT + 100)))"

echo "=== ALL TESTS COMPLETE ==="
