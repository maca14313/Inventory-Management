#!/usr/bin/env python3
"""Test the inventory app's stock flow end-to-end."""
import json, urllib.request, sys

BASE = "http://localhost:3000/api"

def api(method, path, data=None):
    headers = {"Content-Type": "application/json", "x-user-id": "1", "x-user-role": "super_admin"}
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(f"{BASE}{path}", data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except Exception as e:
        print(f"  ERROR: {e}")
        if hasattr(e, 'read'):
            try: print(f"  Body: {e.read().decode()[:200]}")
            except: pass
        return None

def get_stock_for_product(pid):
    stocks = api("GET", "/stock") or []
    return [s for s in stocks if s["productId"] == pid]

print("=== 1. INITIAL STOCK FOR PRODUCT 1 ===")
for s in get_stock_for_product(1):
    print(f"  Product {s['productId']} WH {s['warehouseId']}: qty={s['quantity']}")

print("\n=== 2. STOCK IN: +50 FOR PRODUCT 1 IN WH 1 ===")
result = api("POST", "/stock", {"action": "stockIn", "productId": 1, "warehouseId": 1, "quantity": 50})
if result:
    print(f"  Result: qty={result.get('quantity')}")
else:
    print("  ERROR!")

print("\n=== 3. STOCK AFTER IN (should be 75) ===")
for s in get_stock_for_product(1):
    status = "PASS" if s["warehouseId"] == 1 and s["quantity"] == 75 else ""
    print(f"  Product {s['productId']} WH {s['warehouseId']}: qty={s['quantity']} {status}")

print("\n=== 4. CREATE STOCK OUT RECORDER ===")
recorder = api("POST", "/stock-out", {"enterpriseId": 1, "warehouseId": 1, "recorderCode": "TEST-001", "personName": "Test", "personPhone": "555", "personEmail": "t@t.com", "personAddress": "Test", "notes": "Test"})
if recorder:
    print(f"  Created recorder ID: {recorder['id']}")
    rid = recorder["id"]
else:
    print("  ERROR creating recorder!")
    sys.exit(1)

print("\n=== 5. ADD STOCK OUT ITEM: -10 FOR PRODUCT 1 ===")
item = api("POST", f"/stock-out/{rid}/item", {"productId": 1, "warehouseId": 1, "quantity": 10, "unit": "pcs", "isReturnable": False, "notes": "Test out", "enterpriseId": 1})
if item:
    print(f"  Created item ID: {item['id']}")
    iid = item["id"]
else:
    print("  ERROR adding item!")
    sys.exit(1)

print("\n=== 6. STOCK AFTER OUT (should be 65) ===")
for s in get_stock_for_product(1):
    status = "PASS" if s["warehouseId"] == 1 and s["quantity"] == 65 else ""
    print(f"  Product {s['productId']} WH {s['warehouseId']}: qty={s['quantity']} {status}")

print("\n=== 7. DELETE STOCK OUT ITEM (should restore stock) ===")
del_result = api("DELETE", f"/stock-out/{rid}/item/{iid}")
print(f"  Delete result: {del_result}")

print("\n=== 8. STOCK AFTER ITEM DELETE (should be 75) ===")
for s in get_stock_for_product(1):
    status = "PASS" if s["warehouseId"] == 1 and s["quantity"] == 75 else ""
    print(f"  Product {s['productId']} WH {s['warehouseId']}: qty={s['quantity']} {status}")

print("\n=== 9. AUDIT LOGS (last 5) ===")
logs = api("GET", "/audit") or []
for l in logs[:5]:
    print(f"  {l['action']}: {l['details'][:80]}")

print("\n=== 10. PERSISTENCE CHECK ===")
import os
persist_file = "/home/z/my-project/db/ims-data.json"
if os.path.exists(persist_file):
    size = os.path.getsize(persist_file)
    print(f"  Persistence file exists: {size} bytes")
    with open(persist_file) as f:
        d = json.load(f)
    print(f"  Enterprises: {len(d['enterprises'])}, Products: {len(d['products'])}, Stock: {len(d['stock'])}")
else:
    print("  Persistence file NOT found (will be created after first API call)")

print("\n=== ALL TESTS COMPLETE ===")
