module.exports=[61803,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_attachments_counts_route_actions_84a949be.js.map