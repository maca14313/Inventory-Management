module.exports=[22495,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_permissions_seed_route_actions_410076fd.js.map