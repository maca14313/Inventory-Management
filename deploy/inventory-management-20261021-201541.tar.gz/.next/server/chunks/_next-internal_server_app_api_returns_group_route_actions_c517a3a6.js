module.exports=[33048,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_returns_group_route_actions_c517a3a6.js.map