module.exports=[26704,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_attachments_%5Bid%5D_download_route_actions_ca7c350a.js.map