module.exports=[44007,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_returns_route_actions_06952cf2.js.map