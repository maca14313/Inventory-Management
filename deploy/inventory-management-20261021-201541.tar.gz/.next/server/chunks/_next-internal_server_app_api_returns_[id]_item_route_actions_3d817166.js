module.exports=[95310,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_returns_%5Bid%5D_item_route_actions_3d817166.js.map