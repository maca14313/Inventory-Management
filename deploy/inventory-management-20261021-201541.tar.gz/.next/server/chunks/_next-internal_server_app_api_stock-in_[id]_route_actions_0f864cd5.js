module.exports=[58632,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-in_%5Bid%5D_route_actions_0f864cd5.js.map