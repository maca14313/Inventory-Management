module.exports=[31888,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-out_%5Bid%5D_item_route_actions_09bec2e6.js.map