module.exports=[11605,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-out_%5Bid%5D_route_actions_78e44f9f.js.map