module.exports=[24548,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_enterprises_%5Bid%5D_route_actions_bee8ae2e.js.map