module.exports=[42023,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_permissions_subordinates_route_actions_b48a80e0.js.map