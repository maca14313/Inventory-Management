module.exports=[5835,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-in_route_actions_d581ae12.js.map