module.exports=[96915,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_non-returnables_route_actions_babde294.js.map