module.exports=[85867,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warehouses_%5Bid%5D_reset-admin_route_actions_8baf4a79.js.map