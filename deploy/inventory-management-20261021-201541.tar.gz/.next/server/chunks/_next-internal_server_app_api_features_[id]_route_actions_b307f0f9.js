module.exports=[1565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_features_%5Bid%5D_route_actions_b307f0f9.js.map