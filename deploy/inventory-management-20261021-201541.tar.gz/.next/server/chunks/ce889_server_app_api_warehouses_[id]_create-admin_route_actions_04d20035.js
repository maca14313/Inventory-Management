module.exports=[82339,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_warehouses_%5Bid%5D_create-admin_route_actions_04d20035.js.map