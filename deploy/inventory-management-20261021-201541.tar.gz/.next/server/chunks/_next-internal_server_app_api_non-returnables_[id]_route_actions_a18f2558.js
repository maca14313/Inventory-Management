module.exports=[90932,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_non-returnables_%5Bid%5D_route_actions_a18f2558.js.map