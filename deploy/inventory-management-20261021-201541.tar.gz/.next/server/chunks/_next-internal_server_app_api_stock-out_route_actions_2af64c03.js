module.exports=[68531,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-out_route_actions_2af64c03.js.map