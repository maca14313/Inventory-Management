module.exports=[97446,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lots_route_actions_251fd661.js.map