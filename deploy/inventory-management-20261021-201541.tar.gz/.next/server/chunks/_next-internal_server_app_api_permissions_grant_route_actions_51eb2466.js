module.exports=[55524,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_permissions_grant_route_actions_51eb2466.js.map