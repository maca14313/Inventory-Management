module.exports=[7194,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_non-returnables_group_route_actions_7169e213.js.map