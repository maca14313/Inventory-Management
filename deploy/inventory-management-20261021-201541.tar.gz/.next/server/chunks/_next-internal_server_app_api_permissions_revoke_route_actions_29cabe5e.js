module.exports=[4540,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_permissions_revoke_route_actions_29cabe5e.js.map