module.exports=[82319,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_branches_%5Bid%5D_create-admin_route_actions_edb480d2.js.map