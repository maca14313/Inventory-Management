module.exports=[11806,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock-in_%5Bid%5D_item_route_actions_c70d1a6d.js.map