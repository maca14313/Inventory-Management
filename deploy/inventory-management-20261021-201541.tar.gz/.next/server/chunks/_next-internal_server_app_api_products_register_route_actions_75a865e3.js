module.exports=[61638,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_register_route_actions_75a865e3.js.map