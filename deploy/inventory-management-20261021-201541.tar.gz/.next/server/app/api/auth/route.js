var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/route.js")
R.c("server/chunks/[root-of-the-server]__0355f470._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/node_modules_next_47e236f8._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_route_actions_693293fe.js")
R.m(48928)
module.exports=R.m(48928).exports
