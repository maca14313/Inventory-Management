var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/suppliers/route.js")
R.c("server/chunks/_1f2a0a8b._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_suppliers_route_actions_13ea8c92.js")
R.m(50346)
module.exports=R.m(50346).exports
