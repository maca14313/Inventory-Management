var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/non-returnables/group/route.js")
R.c("server/chunks/_fd965907._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_non-returnables_group_route_actions_7169e213.js")
R.m(80764)
module.exports=R.m(80764).exports
