var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/non-returnables/[id]/route.js")
R.c("server/chunks/_3300dce3._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_non-returnables_[id]_route_actions_a18f2558.js")
R.m(88287)
module.exports=R.m(88287).exports
