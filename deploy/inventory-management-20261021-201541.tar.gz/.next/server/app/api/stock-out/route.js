var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stock-out/route.js")
R.c("server/chunks/_fcfec4b9._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_stock-out_route_actions_2af64c03.js")
R.m(3108)
module.exports=R.m(3108).exports
