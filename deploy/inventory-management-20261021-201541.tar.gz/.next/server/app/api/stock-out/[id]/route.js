var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock-out/[id]/route.js")
R.c("server/chunks/_0114c38b._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_stock-out_[id]_route_actions_78e44f9f.js")
R.m(38409)
module.exports=R.m(38409).exports
