var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock-out/[id]/item/[itemId]/route.js")
R.c("server/chunks/_9c4fd713._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/ce889_server_app_api_stock-out_[id]_item_[itemId]_route_actions_ad9cc5f3.js")
R.m(37852)
module.exports=R.m(37852).exports
