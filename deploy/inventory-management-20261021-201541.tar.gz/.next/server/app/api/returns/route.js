var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/route.js")
R.c("server/chunks/_a2d36674._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_returns_route_actions_06952cf2.js")
R.m(87989)
module.exports=R.m(87989).exports
