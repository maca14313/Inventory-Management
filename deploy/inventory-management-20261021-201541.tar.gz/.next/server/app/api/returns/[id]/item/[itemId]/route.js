var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/[id]/item/[itemId]/route.js")
R.c("server/chunks/[root-of-the-server]__f42f9fb3._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_returns_[id]_item_[itemId]_route_actions_549c0dfa.js")
R.m(37403)
module.exports=R.m(37403).exports
