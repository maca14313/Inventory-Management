var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/[id]/item/route.js")
R.c("server/chunks/[root-of-the-server]__266eb458._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_returns_[id]_item_route_actions_3d817166.js")
R.m(53841)
module.exports=R.m(53841).exports
