var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/returns/process/route.js")
R.c("server/chunks/[root-of-the-server]__dd9e44f2._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_returns_process_route_actions_01326462.js")
R.m(33844)
module.exports=R.m(33844).exports
