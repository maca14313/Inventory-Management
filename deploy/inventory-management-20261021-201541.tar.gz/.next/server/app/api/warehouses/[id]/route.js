var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/warehouses/[id]/route.js")
R.c("server/chunks/_4277bbe7._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_warehouses_[id]_route_actions_06c0e406.js")
R.m(63835)
module.exports=R.m(63835).exports
