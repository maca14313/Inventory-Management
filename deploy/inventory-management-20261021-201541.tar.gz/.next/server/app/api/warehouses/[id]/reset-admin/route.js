var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warehouses/[id]/reset-admin/route.js")
R.c("server/chunks/node_modules_dcaa39a3._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_warehouses_[id]_reset-admin_route_actions_8baf4a79.js")
R.m(75508)
module.exports=R.m(75508).exports
