var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/warehouses/[id]/create-admin/route.js")
R.c("server/chunks/node_modules_b2e165ff._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_warehouses_[id]_create-admin_route_actions_04d20035.js")
R.m(96154)
module.exports=R.m(96154).exports
