var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/warehouses/route.js")
R.c("server/chunks/_f7265115._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_warehouses_route_actions_50103f5e.js")
R.m(97635)
module.exports=R.m(97635).exports
