var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/branches/[id]/create-admin/route.js")
R.c("server/chunks/node_modules_39720279._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_branches_[id]_create-admin_route_actions_edb480d2.js")
R.m(54610)
module.exports=R.m(54610).exports
