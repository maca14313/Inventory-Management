var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/branches/[id]/reset-admin/route.js")
R.c("server/chunks/node_modules_0c92eb45._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_branches_[id]_reset-admin_route_actions_092e4f10.js")
R.m(77410)
module.exports=R.m(77410).exports
