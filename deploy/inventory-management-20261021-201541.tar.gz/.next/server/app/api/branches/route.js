var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/branches/route.js")
R.c("server/chunks/_a8a1c81f._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_branches_route_actions_13d2d717.js")
R.m(67805)
module.exports=R.m(67805).exports
