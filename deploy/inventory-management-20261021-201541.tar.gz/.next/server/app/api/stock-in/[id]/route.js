var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock-in/[id]/route.js")
R.c("server/chunks/_fd941ebc._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_stock-in_[id]_route_actions_0f864cd5.js")
R.m(32822)
module.exports=R.m(32822).exports
