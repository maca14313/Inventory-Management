var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock-in/[id]/item/route.js")
R.c("server/chunks/_ad0756d7._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_stock-in_[id]_item_route_actions_c70d1a6d.js")
R.m(506)
module.exports=R.m(506).exports
