var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ai-assistant/route.js")
R.c("server/chunks/[root-of-the-server]__e79fc1f2._.js")
R.c("server/chunks/[root-of-the-server]__b59cd136._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_ai-assistant_route_actions_234b49a6.js")
R.m(70961)
module.exports=R.m(70961).exports
