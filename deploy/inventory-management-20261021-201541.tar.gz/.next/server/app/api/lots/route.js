var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lots/route.js")
R.c("server/chunks/_7f140284._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_lots_route_actions_251fd661.js")
R.m(68364)
module.exports=R.m(68364).exports
