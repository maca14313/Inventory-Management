var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/features/[id]/route.js")
R.c("server/chunks/_63a7b710._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_features_[id]_route_actions_b307f0f9.js")
R.m(76072)
module.exports=R.m(76072).exports
