var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/features/route.js")
R.c("server/chunks/_79603830._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/src_lib_db_ts_86d9618b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/_next-internal_server_app_api_features_route_actions_64ca1ff4.js")
R.m(11403)
module.exports=R.m(11403).exports
