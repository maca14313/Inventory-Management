var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/enterprises/[id]/create-admin/route.js")
R.c("server/chunks/node_modules_9edcd6d0._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_enterprises_[id]_create-admin_route_actions_89c266d7.js")
R.m(34291)
module.exports=R.m(34291).exports
