var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/enterprises/[id]/reset-admin/route.js")
R.c("server/chunks/node_modules_2f0b6a64._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_enterprises_[id]_reset-admin_route_actions_ed36952f.js")
R.m(40605)
module.exports=R.m(40605).exports
