var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/permissions/subordinates/route.js")
R.c("server/chunks/_78c2e61a._.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_permissions_subordinates_route_actions_b48a80e0.js")
R.m(99108)
module.exports=R.m(99108).exports
