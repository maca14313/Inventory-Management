var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/permissions/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_24930ea9.js")
R.c("server/chunks/[root-of-the-server]__615e5211._.js")
R.c("server/chunks/[root-of-the-server]__1cdc9b7b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_permissions_route_actions_fead90fb.js")
R.m(41280)
module.exports=R.m(41280).exports
