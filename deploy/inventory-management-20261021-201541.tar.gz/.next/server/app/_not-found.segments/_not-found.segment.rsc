1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/2d46f11719722bdc.js","/_next/static/chunks/cbb51892ba515b66.js","/_next/static/chunks/74f1b9da08b28ae5.js"],"default"]
3:I[37457,["/_next/static/chunks/2d46f11719722bdc.js","/_next/static/chunks/cbb51892ba515b66.js","/_next/static/chunks/74f1b9da08b28ae5.js"],"default"]
0:{"buildId":"fThdUxygPrQEjiZ8_Y348","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
