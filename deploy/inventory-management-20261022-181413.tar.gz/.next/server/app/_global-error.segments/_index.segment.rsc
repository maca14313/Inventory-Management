1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/74f1b9da08b28ae5.js"],"default"]
3:I[37457,["/_next/static/chunks/74f1b9da08b28ae5.js"],"default"]
0:{"buildId":"6fjACPXOZ3aMLixvUfk9x","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
