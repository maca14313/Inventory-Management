:HL["/_next/static/chunks/7af0e173cf372ed8.css","style"]
:HL["/_next/static/chunks/870a4a68b0852b50.css","style"]
0:{"buildId":"6fjACPXOZ3aMLixvUfk9x","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
